﻿namespace MH3U
{
    using System;
    using System.Linq;
    using System.Text.RegularExpressions;
    using System.Reflection;
    using System.Threading;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Timers;
    using System.Diagnostics;
    using System.Collections.Generic;
    using System.Windows.Media;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;

    using MH3U.Properties;

    public partial class MainWindow
    {
        private TcpConn tcpConn;

        private Gecko gecko;

        private bool connected;

        private Window1 Win1;

        //Setup Array Database
        private string[,] Equipment_ID;
        //private string[,] Chest;
        //private string[,] Arm;
        //private string[,] Waist;
        //private string[,] Pants;
        //private string[,] Head;
        //Talisman is really just skill sets
        private string[,] CharmSkills;
        //private string[,] Great_Sword;
        //private string[,] Sword_And_Shield;
        //private string[,] Hammer;
        //private string[,] Lance;
        //private string[,] Heavy_Crossbow;
        //private string[,] Light_Crossbow;
        //private string[,] Long_Sword;
        //private string[,] Switch_Axe;
        //private string[,] Gun_Lance;
        //private string[,] Bow;
        //private string[,] Double_Blades;
        //private string[,] Hunting_Horn;
        private string[,] Jewels;
        private string[,] FoodSkills;
        //Have implemented
        private string[,] ItemNames;
        private string[,] UItemNames;
        private string[,] MonsterNames;
        private string[,] PlayerSkills;

        //public static System.Timers.Timer aTimer;
        public static System.Windows.Threading.DispatcherTimer aTimer;

        private const double CycleInterval = 10000;

        private Int32 RTotCounter = 0;
        private Int32 WTotCounter = 0;
        private Int32 RCounter = 0;
        private Int32 WCounter = 0;

        private bool EQViewFlag = false;

        private UInt32 GMonster1Address = 0;
        private UInt32 GMonster2Address = 0;

        public MainWindow()
        {
            InitializeComponent();
            this.Show();
            Win1 = new Window1();
            Win1.Hide();

            IpAddress.Text = Settings.Default.IpAddress;

            //populate combobox with page,row, and col numbers
            int count = 10;
            for (int i = 1; i <= count; i++)
            {
                WPage1.Items.Add(i);
                WRow1.Items.Add(i);
                WCol1.Items.Add(i);

                WPage21.Items.Add(i);
                WRow21.Items.Add(i);
                WCol21.Items.Add(i);

                WPage31.Items.Add(i);
                WRow31.Items.Add(i);
                WCol31.Items.Add(i);

                WPage41.Items.Add(i);
                WRow41.Items.Add(i);
                WCol41.Items.Add(i);

                WPage51.Items.Add(i);
                WRow51.Items.Add(i);
                WCol51.Items.Add(i);

                WPage61.Items.Add(i);
                WRow61.Items.Add(i);
                WCol61.Items.Add(i);

                EQRPage.Items.Add(i);
                EQRRow.Items.Add(i);
                EQRCol.Items.Add(i);

                EQWPage.Items.Add(i);
                EQWRow.Items.Add(i);
                EQWCol.Items.Add(i);

                ItemRPage1.Items.Add(i);
                ItemRRow1.Items.Add(i);
                ItemRCol1.Items.Add(i);

                ItemRPage2.Items.Add(i);
                ItemRRow2.Items.Add(i);
                ItemRCol2.Items.Add(i);

                ItemWPage.Items.Add(i);
                ItemWRow.Items.Add(i);
                ItemWCol.Items.Add(i);
            }

            WPage1.SelectedIndex = 0;
            WRow1.SelectedIndex = 0;
            WCol1.SelectedIndex = 0;

            WPage21.SelectedIndex = 0;
            WRow21.SelectedIndex = 0;
            WCol21.SelectedIndex = 0;

            WPage31.SelectedIndex = 0;
            WRow31.SelectedIndex = 0;
            WCol31.SelectedIndex = 0;

            WPage41.SelectedIndex = 0;
            WRow41.SelectedIndex = 0;
            WCol41.SelectedIndex = 0;

            WPage51.SelectedIndex = 0;
            WRow51.SelectedIndex = 0;
            WCol51.SelectedIndex = 0;

            WPage61.SelectedIndex = 0;
            WRow61.SelectedIndex = 0;
            WCol61.SelectedIndex = 0;

            EQRPage.SelectedIndex = 0;
            EQRRow.SelectedIndex = 0;
            EQRCol.SelectedIndex = 0;

            EQWPage.SelectedIndex = 0;
            EQWRow.SelectedIndex = 0;
            EQWCol.SelectedIndex = 0;

            ItemRPage1.SelectedIndex = 0;
            ItemRRow1.SelectedIndex = 0;
            ItemRCol1.SelectedIndex = 0;

            ItemRPage2.SelectedIndex = 0;
            ItemRRow2.SelectedIndex = 0;
            ItemRCol2.SelectedIndex = 0;

            ItemWPage.SelectedIndex = 0;
            ItemWRow.SelectedIndex = 0;
            ItemWCol.SelectedIndex = 0;

            //======================================
            //populate talisman rare and slots here
            EQRare.Items.Add("None");
            EQRare.Items.Add("Pawn");
            EQRare.Items.Add("Bishop");
            EQRare.Items.Add("Knight");
            EQRare.Items.Add("Rook");
            EQRare.Items.Add("Queen");
            EQRare.Items.Add("King");
            EQRare.Items.Add("Dragon");
            EQRare.Items.Add("Hero");
            EQRare.Items.Add("Legend");
            EQRare.Items.Add("Creator");

            EQSlots.Items.Add("0");
            EQSlots.Items.Add("1");
            EQSlots.Items.Add("2");
            EQSlots.Items.Add("3");

            for (int i = 1; i <= 24; i++)
            {
                PouchSpaceNum.Items.Add(i);
            }

            for (int i = 1; i <= 8; i++)
            {
                PouchSpaceNum.Items.Add("G" + i);
            }

            //======================================
            //********************************************
            // Create a timer with a five second interval.
            aTimer = new System.Windows.Threading.DispatcherTimer();
            aTimer.Tick += new EventHandler(OnTimedEvent);
            aTimer.Interval = TimeSpan.FromSeconds(1);
            aTimer.Stop();

            //This is for debug only
            //ToggleControls("Replicator");
            
            //Initial dababase must come before calling EquipmentView
            InitializeArrayDB();
            EquipmentView("initialize","none");

            //EQType.SelectedIndex = 1;
           
        }

        private void ConnectClick(object sender, RoutedEventArgs e)
        {
            try
            {
                tcpConn = new TcpConn(IpAddress.Text, 7331);
                connected = tcpConn.Connect();

                if (!connected)
                {
                    LogError(new Exception("Failed to connect"));
                    return;
                }

                // init gecko
                gecko = new Gecko(tcpConn, this);

                if (connected)
                {
                    var status = gecko.GetServerStatus();
                    if (status == 0)
                    {
                        return;
                    }

                    // Saved settings stuff
                    Settings.Default.IpAddress = IpAddress.Text;
                    Settings.Default.Save();

                    //Controller.SelectedValue = Settings.Default.Controller;

                    ToggleControls("Connected");
                    ToggleControls("Replicator");
                    
                }
            }
            catch (System.Net.Sockets.SocketException)
            {
                connected = false;

                MessageBox.Show("Wrong IP");
            }
            catch (Exception ex)
            {
                LogError(ex);
            }
        }

        private void DisconnectClick(object sender, RoutedEventArgs e)
        {
            try
            {
                tcpConn.Close();

                ToggleControls("Disconnected");
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void LogError(Exception ex, string more = null)
        {
            var paragraph = new Paragraph
            {
                FontSize = 14,
                Margin = new Thickness(0),
                Padding = new Thickness(0),
                LineHeight = 14
            };

            if (more != null)
            {
                paragraph.Inlines.Add(more + Environment.NewLine);
            }

            paragraph.Inlines.Add(ex.Message);
            paragraph.Inlines.Add(ex.StackTrace);

            ErrorLog.Document.Blocks.Add(paragraph);

            ErrorLog.Document.Blocks.Add(new Paragraph());

            TabControl.IsEnabled = true;

            MessageBox.Show("Error caught. Check Error Tab");
        }

        private void TabControlSelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ToggleControls(string state)
        {
            if (state == "Connected")
            {
                Connect.IsEnabled = false;
                Connect.Visibility = Visibility.Hidden;

                Disconnect.IsEnabled = true;
                Disconnect.Visibility = Visibility.Visible;

                IpAddress.IsEnabled = false;
            }

            if (state == "Disconnected")
            {
                Connect.IsEnabled = true;
                Connect.Visibility = Visibility.Visible;
                Disconnect.IsEnabled = false;
                Disconnect.Visibility = Visibility.Hidden;
                IpAddress.IsEnabled = true;
            }

            if (state == "Replicator")
            {
                //Load.IsEnabled = false;
                //Load.Visibility = Visibility.Hidden;
                //Save.IsEnabled = true;
                //Refresh.IsEnabled = true;
                CBMonsterEnable.IsChecked = true;
                //Replicator.IsEnabled = true;
                Capture.IsEnabled = true;
                //Write.IsEnabled = true;
                ReadSkills.IsEnabled = true;
                //WriteSkills.IsEnabled = true;
                WeaponRead1.IsEnabled = true;
                WeaponRead2.IsEnabled = true;
                WeaponRead3.IsEnabled = true;
                WeaponRead4.IsEnabled = true;
                WeaponRead5.IsEnabled = true;
                WeaponWrite.IsEnabled = true;
                //EQRead.IsEnabled = true;
                EQWrite.IsEnabled = true;
                ItemRead1.IsEnabled = true;
                ItemRead2.IsEnabled = true;
                ItemWrite.IsEnabled = true;
                WQuest.IsEnabled = true;

                TabControl.IsEnabled = true;
            }

        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            //close win1 frist
            Win1.Close();
            // Shutdown the application.
            Application.Current.Shutdown();
            // OR You can Also go for below logic
            // Environment.Exit(0);
        }

        public void SetTimer(string OffOn)
        {

            //var Covert2Sec = (Convert.ToInt16(UpdateInterval.Text));

            //set new time interval
            //aTimer.Interval = Covert2Sec;
            //aTimer.Interval = TimeSpan.FromSeconds(Covert2Sec);
            
            if (OffOn == "OFF")
            {
                aTimer.Stop();
                //aTimer.Enabled = false;
            }
            else if (OffOn == "ON")
            {
                aTimer.Start();
                //aTimer.Enabled = true;
            }
        }

        public void OnTimedEvent(Object source, EventArgs e)
        {
            var playerpointer = gecko.GetUInt(0x2F41FAFC);

            if (playerpointer == 0x0 || playerpointer < 0x30000000)
            {
                //Player is probably no longer on a quest
                //shut off replicator
                Replicator.Content = "Run";
                SetTimer("OFF");
                Capture.IsEnabled = true;
                Write.IsEnabled = true;
            }
            else if (playerpointer > 0x30000000)
            {
                //Player is still on a quest
                //Check for write data counter first
                if (WCounter >= Convert.ToInt16(WriteInterval.Text))
                {
                    //write data
                    WCounter = 1; //need to set to 1 and not zero because we're writing now
                    WTotCounter += 1;
                    DisplayWCounter.Text = Convert.ToString(WTotCounter);

                    bool result = WriteReplicateData();
                    
                    if (result == false)
                    {
                        //something has gone wrong, must shut off replicator
                        Replicator.Content = "Run";
                        SetTimer("OFF");
                        Capture.IsEnabled = true;
                        Write.IsEnabled = true;
                    }
                }
                else { WCounter += 1; }

                //Check for read data counter
                if (RCounter >= Convert.ToInt16(ReadInterval.Text))
                {
                    //read data
                    RCounter = 1; //need to set to 1 and not zero because we're reading now
                    RTotCounter += 1;
                    DisplayRCounter.Text = Convert.ToString(RTotCounter);

                    bool result = ReadReplicateData();

                    if (result == false)
                    {
                        //something has gone wrong, must shut off replicator
                        Replicator.Content = "Run";
                        SetTimer("OFF");
                        Capture.IsEnabled = true;
                        Write.IsEnabled = true;
                    }
                }
                else { RCounter += 1; }
            }
            else
            {
                //Something has gone wrong, shut off replicator
                Replicator.Content = "Run";
                SetTimer("OFF");
                Capture.IsEnabled = true;
                Write.IsEnabled = true;

            }

        }

        private void CheckBoxChanged(object sender, RoutedEventArgs e)
        {
            if (CBMonsterEnable.IsChecked == true)
            {
                MonsterName1.Content = "";
                MonsterName1.Background = System.Windows.Media.Brushes.Yellow;
                MonsterName2.Content = "";
                MonsterName2.Background = System.Windows.Media.Brushes.Aqua;
            }
            else if (CBMonsterEnable.IsChecked == false)
            {
                MonsterName1.Content = "";
                MonsterName1.Background = System.Windows.Media.Brushes.LightGray;
                Mon1MaxHealth1.Content = "0";
                Mon1Health1.Content = "0";
                Monster1HealthBar.Value = 0;
                Mon1Percent1.Content = "0 %";
                GMonster1Address = 0;

                MonsterName2.Content = "";
                MonsterName2.Background = System.Windows.Media.Brushes.LightGray;
                Mon2MaxHealth2.Content = "0";
                Mon2Health2.Content = "0";
                Monster2HealthBar.Value = 0;
                Mon2Percent2.Content = "0 %";
                GMonster2Address = 0;
            }
        }

        private void MonsterHealth1()
        {
            var AddressList = new List<uint> { 0x2F3EF944, 0x2F3EFBA4, 0x2F3EFE04, 0x2F3F0064, 0x2F3F02C4 };

            //First Monster
            if (GMonster1Address == 0)
            {
                foreach (var MonsterAddr in AddressList)
                {
                    if (MonsterAddr != GMonster2Address)
                    {
                        var Monster1Pointer = gecko.GetUInt(MonsterAddr);
                        var Monster1Address = Monster1Pointer + 0x0;

                        if (Monster1Address > 0x30000000)
                        {
                            var Monster1Data = gecko.ReadBytes(Monster1Address, 0x04);

                            if (Monster1Data != null && Monster1Data.Length > 0)
                            {
                                var Monster1Status = BitConverter.ToUInt16(Monster1Data.Skip(0).Take(2).Reverse().ToArray(), 0);
                                var Monster1Type = BitConverter.ToUInt16(Monster1Data.Skip(2).Take(2).Reverse().ToArray(), 0);

                                ushort number = Convert.ToUInt16(Monster1Type);
                                byte Upper = (byte)(number >> 8);
                                byte Lower = (byte)(number & 0xff);

                                int TUpper = Convert.ToUInt16(Upper);
                                int TLower = Convert.ToUInt16(Lower);

                                if (TLower <= 85 && TUpper <= 1 && Monster1Status.ToString("X4") == "0101")
                                {

                                    var Monster1ID = TLower.ToString("X2");

                                    int Monster1Index = LookUpArrayID(Monster1ID, MonsterNames);

                                    if (Monster1Index != 0 && MonsterAddr != GMonster2Address)
                                    {
                                        MonsterName1.Content = MonsterNames[Monster1Index, 1];
                                        GMonster1Address = MonsterAddr;
                                        //Monster1Pointer = gecko.GetUInt(GMonster1Address);
                                        Monster1Address = Monster1Pointer + 0x8B8;
                                        Monster1Data = gecko.ReadBytes(Monster1Address, 0x08);

                                        var Mon1CurHealth = BitConverter.ToInt32(Monster1Data.Skip(0).Take(4).Reverse().ToArray(), 0);
                                        var Mon1MaxHealth = BitConverter.ToInt32(Monster1Data.Skip(4).Take(4).Reverse().ToArray(), 0);
                                        var Mon1Percent = (100m / Mon1MaxHealth) * Mon1CurHealth;
                                        Mon1MaxHealth1.Content = Convert.ToString(Mon1MaxHealth);
                                        Mon1Health1.Content = Convert.ToString(Mon1CurHealth);
                                        Monster1HealthBar.Value = Convert.ToInt32(Mon1Percent);
                                        int TempPercent = Convert.ToInt32(Mon1Percent);
                                        Mon1Percent1.Content = TempPercent.ToString() + " %";
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                if (GMonster1Address != GMonster2Address)
                {
                    var Monster1Pointer = gecko.GetUInt(GMonster1Address);
                    var Monster1Address = Monster1Pointer + 0x0;

                    if (Monster1Address > 0x30000000)
                    {
                        var Monster1Data = gecko.ReadBytes(Monster1Address, 0x04);

                        if (Monster1Data != null && Monster1Data.Length > 0)
                        {
                            var Monster1Status = BitConverter.ToUInt16(Monster1Data.Skip(0).Take(2).Reverse().ToArray(), 0);
                            var Monster1Type = BitConverter.ToUInt16(Monster1Data.Skip(2).Take(2).Reverse().ToArray(), 0);

                            ushort number = Convert.ToUInt16(Monster1Type);
                            byte Upper = (byte)(number >> 8);
                            byte Lower = (byte)(number & 0xff);

                            int TUpper = Convert.ToUInt16(Upper);
                            int TLower = Convert.ToUInt16(Lower);

                            if (TLower > 85 || TUpper > 1 || Monster1Status.ToString("X4") != "0101")
                            {
                                MonsterName1.Content = "";
                                Mon1MaxHealth1.Content = "0";
                                Mon1Health1.Content = "0";
                                Monster1HealthBar.Value = 0;
                                Mon1Percent1.Content = "0 %";
                                GMonster1Address = 0;
                                return;
                            }

                            var Monster1ID = TLower.ToString("X2");

                            int Monster1Index = LookUpArrayID(Monster1ID, MonsterNames);

                            if (Monster1Index != 0)
                            {
                                MonsterName1.Content = MonsterNames[Monster1Index, 1];
                                //Monster1Pointer = gecko.GetUInt(GMonster1Address);
                                Monster1Address = Monster1Pointer + 0x8B8;
                                Monster1Data = gecko.ReadBytes(Monster1Address, 0x08);

                                var Mon1CurHealth = BitConverter.ToInt32(Monster1Data.Skip(0).Take(4).Reverse().ToArray(), 0);
                                var Mon1MaxHealth = BitConverter.ToInt32(Monster1Data.Skip(4).Take(4).Reverse().ToArray(), 0);
                                var Mon1Percent = (100m / Mon1MaxHealth) * Mon1CurHealth;
                                Mon1MaxHealth1.Content = Convert.ToString(Mon1MaxHealth);
                                Mon1Health1.Content = Convert.ToString(Mon1CurHealth);
                                Monster1HealthBar.Value = Convert.ToInt32(Mon1Percent);
                                int TempPercent = Convert.ToInt32(Mon1Percent);
                                Mon1Percent1.Content = TempPercent.ToString() + " %";
                            }
                            else
                            {
                                MonsterName1.Content = "";
                                Mon1MaxHealth1.Content = "0";
                                Mon1Health1.Content = "0";
                                Monster1HealthBar.Value = 0;
                                Mon1Percent1.Content = "0 %";
                                GMonster1Address = 0;
                            }
                        }
                        else
                        {
                            MonsterName1.Content = "";
                            Mon1MaxHealth1.Content = "0";
                            Mon1Health1.Content = "0";
                            Monster1HealthBar.Value = 0;
                            Mon1Percent1.Content = "0 %";
                            GMonster1Address = 0;
                        }
                    }
                }
                else
                {
                    MonsterName1.Content = "";
                    Mon1MaxHealth1.Content = "0";
                    Mon1Health1.Content = "0";
                    Monster1HealthBar.Value = 0;
                    Mon1Percent1.Content = "0 %";
                    GMonster1Address = 0;
                }
            }
                       
        }

        private void MonsterHealth2()
        {
            var AddressList = new List<uint> { 0x2F3EF944, 0x2F3EFBA4, 0x2F3EFE04, 0x2F3F0064, 0x2F3F02C4 };
                        
            //Second Monster
            if (GMonster2Address == 0)
            {
                foreach (var MonsterAddr in AddressList)
                {
                    if (MonsterAddr != GMonster1Address)
                    {
                        var Monster2Pointer = gecko.GetUInt(MonsterAddr);
                        var Monster2Address = Monster2Pointer + 0x0;

                        if (Monster2Address > 0x30000000)
                        {
                            var Monster2Data = gecko.ReadBytes(Monster2Address, 0x04);

                            if (Monster2Data != null && Monster2Data.Length > 0)
                            {
                                var Monster2Status = BitConverter.ToUInt16(Monster2Data.Skip(0).Take(2).Reverse().ToArray(), 0);
                                var Monster2Type = BitConverter.ToUInt16(Monster2Data.Skip(2).Take(2).Reverse().ToArray(), 0);

                                ushort number = Convert.ToUInt16(Monster2Type);
                                byte Upper = (byte)(number >> 8);
                                byte Lower = (byte)(number & 0xff);

                                int TUpper = Convert.ToUInt16(Upper);
                                int TLower = Convert.ToUInt16(Lower);

                                if (TLower <= 85 && TUpper <= 1 && Monster2Status.ToString("X4") == "0101")
                                {
                                    var Monster2ID = TLower.ToString("X2");

                                    int Monster2Index = LookUpArrayID(Monster2ID, MonsterNames);

                                    if (Monster2Index != 0 && MonsterAddr != GMonster1Address)
                                    {
                                        MonsterName2.Content = MonsterNames[Monster2Index, 1];
                                        GMonster2Address = MonsterAddr;
                                        //Monster1Pointer = gecko.GetUInt(GMonster1Address);
                                        Monster2Address = Monster2Pointer + 0x8B8;
                                        Monster2Data = gecko.ReadBytes(Monster2Address, 0x08);

                                        var Mon2CurHealth = BitConverter.ToInt32(Monster2Data.Skip(0).Take(4).Reverse().ToArray(), 0);
                                        var Mon2MaxHealth = BitConverter.ToInt32(Monster2Data.Skip(4).Take(4).Reverse().ToArray(), 0);
                                        var Mon2Percent = (100m / Mon2MaxHealth) * Mon2CurHealth;
                                        Mon2MaxHealth2.Content = Convert.ToString(Mon2MaxHealth);
                                        Mon2Health2.Content = Convert.ToString(Mon2CurHealth);
                                        Monster2HealthBar.Value = Convert.ToInt32(Mon2Percent);
                                        int TempPercent = Convert.ToInt32(Mon2Percent);
                                        Mon2Percent2.Content = TempPercent.ToString() + " %";
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                if (GMonster1Address != GMonster2Address)
                {
                    var Monster2Pointer = gecko.GetUInt(GMonster2Address);
                    var Monster2Address = Monster2Pointer + 0x0;

                    if (Monster2Address > 0x30000000)
                    {
                        var Monster2Data = gecko.ReadBytes(Monster2Address, 0x04);

                        if (Monster2Data != null && Monster2Data.Length > 0)
                        {
                            var Monster2Status = BitConverter.ToUInt16(Monster2Data.Skip(0).Take(2).Reverse().ToArray(), 0);
                            var Monster2Type = BitConverter.ToUInt16(Monster2Data.Skip(2).Take(2).Reverse().ToArray(), 0);

                            ushort number = Convert.ToUInt16(Monster2Type);
                            byte Upper = (byte)(number >> 8);
                            byte Lower = (byte)(number & 0xff);

                            int TUpper = Convert.ToUInt16(Upper);
                            int TLower = Convert.ToUInt16(Lower);

                            if (TLower > 85 || TUpper > 1 || Monster2Status.ToString("X4") != "0101")
                            {
                                MonsterName2.Content = "";
                                Mon2MaxHealth2.Content = "0";
                                Mon2Health2.Content = "0";
                                Monster2HealthBar.Value = 0;
                                Mon2Percent2.Content = "0 %";
                                GMonster2Address = 0;
                                return;
                            }

                            var Monster2ID = TLower.ToString("X2");

                            int Monster2Index = LookUpArrayID(Monster2ID, MonsterNames);

                            if (Monster2Index != 0)
                            {
                                MonsterName2.Content = MonsterNames[Monster2Index, 1];
                                //Monster1Pointer = gecko.GetUInt(GMonster1Address);
                                Monster2Address = Monster2Pointer + 0x8B8;
                                Monster2Data = gecko.ReadBytes(Monster2Address, 0x08);

                                var Mon2CurHealth = BitConverter.ToInt32(Monster2Data.Skip(0).Take(4).Reverse().ToArray(), 0);
                                var Mon2MaxHealth = BitConverter.ToInt32(Monster2Data.Skip(4).Take(4).Reverse().ToArray(), 0);
                                var Mon2Percent = (100m / Mon2MaxHealth) * Mon2CurHealth;
                                Mon2MaxHealth2.Content = Convert.ToString(Mon2MaxHealth);
                                Mon2Health2.Content = Convert.ToString(Mon2CurHealth);
                                Monster2HealthBar.Value = Convert.ToInt32(Mon2Percent);
                                int TempPercent = Convert.ToInt32(Mon2Percent);
                                Mon2Percent2.Content = TempPercent.ToString() + " %";
                            }
                            else
                            {
                                MonsterName2.Content = "";
                                Mon2MaxHealth2.Content = "0";
                                Mon2Health2.Content = "0";
                                Monster2HealthBar.Value = 0;
                                Mon2Percent2.Content = "0 %";
                                GMonster2Address = 0;
                            }
                        }
                        else
                        {
                            MonsterName2.Content = "";
                            Mon2MaxHealth2.Content = "0";
                            Mon2Health2.Content = "0";
                            Monster2HealthBar.Value = 0;
                            Mon2Percent2.Content = "0 %";
                            GMonster2Address = 0;
                        }
                    }
                }
                else
                {
                    MonsterName2.Content = "";
                    Mon2MaxHealth2.Content = "0";
                    Mon2Health2.Content = "0";
                    Monster2HealthBar.Value = 0;
                    Mon2Percent2.Content = "0 %";
                    GMonster2Address = 0;
                }
            }
        }

        private bool ReadReplicateData()
        {
            var playerpointer = gecko.GetUInt(0x2F41FAFC);

            //You must be on a quest to use this WriteData function
            if (playerpointer == 0x0 || playerpointer < 0x30000000)
            {
                //You should never be in here if you're on quest, therefore
                //player either ended the quest or back into village.
                //return a false, so the timer would stop.
                return false;
            }
            else if (playerpointer > 0x30000000)
            {
                if (CBMonsterEnable.IsChecked == true)
                {
                    //Update Monster Status
                    MonsterHealth1();
                    MonsterHealth2();
                }

                return true;
            }
            else
            {
                //something has gone wrong here. Return false and stop the timer
                return false;
            }
           
        }

        private bool WriteReplicateData()
        {
            uint EnableValue = 0x00007F7F;
            uint DisableValue = 0x00000000;
            uint MaxValue = 0x7FFF7FFF;
            //Floating point
            uint InfiniteValue = 0x50000000;
           

            var tCHealth1 = CHealth1.Text;
            var tCHealth2 = CHealth2.Text;

            var playerpointer = gecko.GetUInt(0x2F41FAFC);

            //Just initialize the variable here and assume not on quest
            var pouchpointer = Convert.ToUInt32(0x0);
            var gpouchpointer = Convert.ToUInt32(0x0);

            //You must be on a quest to use this WriteData function
            if (playerpointer == 0x0 || playerpointer < 0x30000000)
            {
                //You should never be in here if you're on quest, therefore
                //player either ended the quest or back into village.
                //return a false, so the timer would stop.
                return false;
            }
            else if (playerpointer > 0x30000000)
            {
                //Player is on a quest, no need to ask anything
                //increment Counter
                RCounter = RCounter + 1;
                DisplayRCounter.Text = Convert.ToString(RCounter);
                //---------------------------------------------------------------------------------
                //Get Blade Pouch Position
                pouchpointer = gecko.GetUInt(0x2F41FAFC);
                //Read Blade Pouch Data
                //pouchData = gecko.ReadBytes(pouchpointer, 0x80);

                //Get Gunner Pouch Position
                gpouchpointer = gecko.GetUInt(0x2F41FB00);
                //Read Gunner Pouch Data
                //gpouchData = gecko.ReadBytes(gpouchpointer, 0x20);

                //Get Health, Stamina, Air,etc
                var playeraddress = playerpointer + 0x168;

                if (CBGHealth.IsChecked == true)
                {
                    var health1 = Convert.ToInt16(CHealth1.Text);
                    var health2 = Convert.ToInt16(CHealth2.Text);
                    gecko.WriteShort(playeraddress, health1);
                    gecko.WriteShort(playeraddress + 0x2, health2);
                }

                if (CBRHealth.IsChecked == true)
                {
                    //This is the redhealth, therefore it's swap in the textbox
                    var u1 = Convert.ToInt16(CU1.Text);
                    var u2 = Convert.ToInt16(CU2.Text);
                    gecko.WriteShort(playeraddress + 0x4, u1);
                    gecko.WriteShort(playeraddress + 0x6, u2);
                }

                if (Win1.CBCStamina.IsChecked == true)
                {
                    var stam1 = Convert.ToSingle(Win1.CStamina1.Text);
                    var stam2 = Convert.ToSingle(Win1.CStamina2.Text);
                    gecko.WriteFloat(playeraddress + 0x8, stam1);
                    gecko.WriteFloat(playeraddress + 0xC, stam2);
                }

                if (Win1.CBCCountdown.IsChecked == true)
                {
                    var count1 = Convert.ToSingle(Win1.CCountdown1.Text);
                    var count2 = Convert.ToSingle(Win1.CCountdown2.Text);
                    gecko.WriteFloat(playeraddress + 0x10, count1);
                    gecko.WriteFloat(playeraddress + 0x14, count2);
                }

                if (Win1.CBCAir.IsChecked == true)
                {
                    var air1 = Convert.ToInt16(Win1.CAir1.Text);
                    var air2 = Convert.ToInt16(Win1.CAir2.Text);
                    gecko.WriteShort(playeraddress + 0x1C, air1);
                    gecko.WriteShort(playeraddress + 0x1E, air2);
                }

                //========================================
                if (CBFoodSkill.IsChecked == true)
                {
                    //Write food skill
                    var foodaddress = playerpointer + 0x966;

                    gecko.WriteBytes(foodaddress, gecko.StringToByteArray(FoodSkill1.Text));
                    gecko.WriteBytes(foodaddress + 0x2, gecko.StringToByteArray(FoodSkill2.Text));
                    gecko.WriteBytes(foodaddress + 0x4, gecko.StringToByteArray(FoodSkill3.Text));
                }

                //========================================
                if (CBActiveSkill.IsChecked == true)
                {
                    //Write Active skill
                    var ActiveSkillAddress = playerpointer + 0x934;

                    gecko.WriteBytes(ActiveSkillAddress, gecko.StringToByteArray(ActiveSkillID1.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0x2, gecko.StringToByteArray(ActiveSkillID2.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0x4, gecko.StringToByteArray(ActiveSkillID3.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0x6, gecko.StringToByteArray(ActiveSkillID4.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0x8, gecko.StringToByteArray(ActiveSkillID5.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0xA, gecko.StringToByteArray(ActiveSkillID6.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0xC, gecko.StringToByteArray(ActiveSkillID7.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0xE, gecko.StringToByteArray(ActiveSkillID8.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0x10, gecko.StringToByteArray(ActiveSkillID9.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0x12, gecko.StringToByteArray(ActiveSkillID10.Text));
                }

                //=======================================
                //Increase all attack up buffs
                if (Win1.CBAttackUp.IsChecked == true)
                {
                    var AttackUpStr = EnableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x414, gecko.StringToByteArray(AttackUpStr));

                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x418, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x454, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x70C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Increase defense up
                if (Win1.CBDefenseUp.IsChecked == true)
                {
                    var DefenseUpStr = Convert.ToSingle(Win1.AddDefenseUp.Text);
                    gecko.WriteFloat(playerpointer + 0x428, DefenseUpStr);

                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x42C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x718, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Invincibility
                if (Win1.CBInvincible.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x1A8, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x1AC, gecko.StringToByteArray(InfiniteValueStr));

                    //Write again to make sure the value stays
                    gecko.WriteBytes(playerpointer + 0x1A8, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x1AC, gecko.StringToByteArray(InfiniteValueStr));
                }

                //=======================================
                //Negate Stun
                if (Win1.CBNegateStun.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x790, gecko.StringToByteArray(InfiniteValueStr));

                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x294, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Poison 
                if (Win1.CBNegatePoison.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x24C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Paralysis
                if (Win1.CBNegateParalysis.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x79C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Negate Tremor/Quake
                if (Win1.CBNegateQuake.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x7A8, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Negate Muddy 
                if (Win1.CBNegateMuddy.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x32C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Snow/Ice 
                if (Win1.CBNegateSnow.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x31C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Soiled/Stench 
                if (Win1.CBNegateSnow.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x408, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Wind
                if (Win1.CBNegateWind.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x730, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x43C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Negate Defense Down 
                if (Win1.CBNegateDefDown.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x33C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Elemental Down 
                if (Win1.CBNegateEleDown.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x348, gecko.StringToByteArray(DisableValueStr));
                    gecko.WriteBytes(playerpointer + 0x358, gecko.StringToByteArray(DisableValueStr));
                    gecko.WriteBytes(playerpointer + 0x368, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Slime  
                if (Win1.CBNegateSlime.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x2AC, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Fire Blight/Negate All Blight 
                if (Win1.CBNegateFire.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x234, gecko.StringToByteArray(DisableValueStr));
                }

                //======================================================
                //Elemental Atk Up
                if (Win1.CBElementalUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x7B4, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Status Atk Up
                if (Win1.CBStatusUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x814, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Purple Sharpness
                if (Win1.CBPurpleSharp.IsChecked == true)
                {
                    var MaxValueStr = MaxValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x624, gecko.StringToByteArray(MaxValueStr));
                }

                //Affinity Up
                if (Win1.CBAffinityUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x808, gecko.StringToByteArray(InfiniteValueStr));
                }

                //HG Earplug
                if (Win1.CBHearing.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x784, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Mega Dash
                if (Win1.CBMegaDash.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x30C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x73C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Move Speed Up / Minds Eye
                if (Win1.CBSpeedUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x700, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Tracker / Show Monster
                if (Win1.CBTracker.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x748, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Hot Cancel / Heat Resist
                if (Win1.CBHotCancel.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x49C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x778, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Cold Cancel / Cold Resist
                if (Win1.CBColdCancel.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x4A8, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x76C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //LS,DB,SA Full Charge
                if (Win1.CBCharge.IsChecked == true)
                {
                    //LS
                    var EnableValueStr = EnableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x194, gecko.StringToByteArray(EnableValueStr));
                    //DB
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x484, gecko.StringToByteArray(InfiniteValueStr));
                    //SA
                    var SAFullCharge = "00640000";
                    gecko.WriteBytes(playerpointer + 0x154, gecko.StringToByteArray(SAFullCharge));
                    //GS
                    //var GSFullCharge = "03030000";
                    //gecko.WriteBytes(playerpointer + 0xAC, gecko.StringToByteArray(GSFullCharge));
                    //Bow
                    //var BowFullCharge = "42A2389B";
                    //gecko.WriteBytes(playerpointer + 0xA0, gecko.StringToByteArray(BowFullCharge));
                    //HM
                    //var HMFullCharge = "42A2389B";
                    //gecko.WriteBytes(playerpointer + 0xA4, gecko.StringToByteArray(HMFullCharge));
                }

                //Dragon Resist
                if (Win1.CBDragonRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x3A4, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3E0, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7F0, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Fire Resist
                if (Win1.CBFireRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x374, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3B0, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7C0, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Water Resist
                if (Win1.CBWaterRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x380, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3BC, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7CC, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Thunder Resist
                if (Win1.CBThunderRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x38C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3C8, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7D8, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Ice Resist
                if (Win1.CBIceRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x398, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3D4, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7E4, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }
                //Can not return true here becuase still need to do pouch items below                               
            }
            else
            {
                //something has gone wrong here. Return false and stop the timer
                return false;
            }

            //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            //==========================================================================================
            //Write Blade Pouch
            //Check to see if we're still on a quest
            playerpointer = gecko.GetUInt(0x2F41FAFC);

            if (playerpointer > 0x30000000 && CBItemEnable.IsChecked == true)
            {
                if (Convert.ToInt16(CPouch1Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer, gecko.StringToByteArray(CPouch1Id.Text));
                    gecko.WriteShort(pouchpointer + 0x2, Convert.ToInt16(CPouch1Amount.Text));
                }

                if (Convert.ToInt16(CPouch2Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x4, gecko.StringToByteArray(CPouch2Id.Text));
                    gecko.WriteShort(pouchpointer + 0x6, Convert.ToInt16(CPouch2Amount.Text));
                }

                if (Convert.ToInt16(CPouch3Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x8, gecko.StringToByteArray(CPouch3Id.Text));
                    gecko.WriteShort(pouchpointer + 0xA, Convert.ToInt16(CPouch3Amount.Text));
                }

                if (Convert.ToInt16(CPouch4Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0xC, gecko.StringToByteArray(CPouch4Id.Text));
                    gecko.WriteShort(pouchpointer + 0xE, Convert.ToInt16(CPouch4Amount.Text));
                }

                if (Convert.ToInt16(CPouch5Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x10, gecko.StringToByteArray(CPouch5Id.Text));
                    gecko.WriteShort(pouchpointer + 0x12, Convert.ToInt16(CPouch5Amount.Text));
                }

                if (Convert.ToInt16(CPouch6Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x14, gecko.StringToByteArray(CPouch6Id.Text));
                    gecko.WriteShort(pouchpointer + 0x16, Convert.ToInt16(CPouch6Amount.Text));
                }

                if (Convert.ToInt16(CPouch7Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x18, gecko.StringToByteArray(CPouch7Id.Text));
                    gecko.WriteShort(pouchpointer + 0x1A, Convert.ToInt16(CPouch7Amount.Text));
                }

                if (Convert.ToInt16(CPouch8Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x1C, gecko.StringToByteArray(CPouch8Id.Text));
                    gecko.WriteShort(pouchpointer + 0x1E, Convert.ToInt16(CPouch8Amount.Text));
                }

                if (Convert.ToInt16(CPouch9Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x20, gecko.StringToByteArray(CPouch9Id.Text));
                    gecko.WriteShort(pouchpointer + 0x22, Convert.ToInt16(CPouch9Amount.Text));
                }

                if (Convert.ToInt16(CPouch10Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x24, gecko.StringToByteArray(CPouch10Id.Text));
                    gecko.WriteShort(pouchpointer + 0x26, Convert.ToInt16(CPouch10Amount.Text));
                }

                if (Convert.ToInt16(CPouch11Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x28, gecko.StringToByteArray(CPouch11Id.Text));
                    gecko.WriteShort(pouchpointer + 0x2A, Convert.ToInt16(CPouch11Amount.Text));
                }

                if (Convert.ToInt16(CPouch12Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x2C, gecko.StringToByteArray(CPouch12Id.Text));
                    gecko.WriteShort(pouchpointer + 0x2E, Convert.ToInt16(CPouch12Amount.Text));
                }

                if (Convert.ToInt16(CPouch13Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x30, gecko.StringToByteArray(CPouch13Id.Text));
                    gecko.WriteShort(pouchpointer + 0x32, Convert.ToInt16(CPouch13Amount.Text));
                }

                if (Convert.ToInt16(CPouch14Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x34, gecko.StringToByteArray(CPouch14Id.Text));
                    gecko.WriteShort(pouchpointer + 0x36, Convert.ToInt16(CPouch14Amount.Text));
                }

                if (Convert.ToInt16(CPouch15Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x38, gecko.StringToByteArray(CPouch15Id.Text));
                    gecko.WriteShort(pouchpointer + 0x3A, Convert.ToInt16(CPouch15Amount.Text));
                }

                if (Convert.ToInt16(CPouch16Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x3C, gecko.StringToByteArray(CPouch16Id.Text));
                    gecko.WriteShort(pouchpointer + 0x3E, Convert.ToInt16(CPouch16Amount.Text));
                }

                if (Convert.ToInt16(CPouch17Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x40, gecko.StringToByteArray(CPouch17Id.Text));
                    gecko.WriteShort(pouchpointer + 0x42, Convert.ToInt16(CPouch17Amount.Text));
                }

                if (Convert.ToInt16(CPouch18Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x44, gecko.StringToByteArray(CPouch18Id.Text));
                    gecko.WriteShort(pouchpointer + 0x46, Convert.ToInt16(CPouch18Amount.Text));
                }

                if (Convert.ToInt16(CPouch19Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x48, gecko.StringToByteArray(CPouch19Id.Text));
                    gecko.WriteShort(pouchpointer + 0x4A, Convert.ToInt16(CPouch19Amount.Text));
                }

                if (Convert.ToInt16(CPouch20Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x4C, gecko.StringToByteArray(CPouch20Id.Text));
                    gecko.WriteShort(pouchpointer + 0x4E, Convert.ToInt16(CPouch20Amount.Text));
                }

                if (Convert.ToInt16(CPouch21Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x50, gecko.StringToByteArray(CPouch21Id.Text));
                    gecko.WriteShort(pouchpointer + 0x52, Convert.ToInt16(CPouch21Amount.Text));
                }

                if (Convert.ToInt16(CPouch22Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x54, gecko.StringToByteArray(CPouch22Id.Text));
                    gecko.WriteShort(pouchpointer + 0x56, Convert.ToInt16(CPouch22Amount.Text));
                }

                if (Convert.ToInt16(CPouch23Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x58, gecko.StringToByteArray(CPouch23Id.Text));
                    gecko.WriteShort(pouchpointer + 0x5A, Convert.ToInt16(CPouch23Amount.Text));
                }

                if (Convert.ToInt16(CPouch24Amount.Text) != 0)
                {
                    gecko.WriteBytes(pouchpointer + 0x5C, gecko.StringToByteArray(CPouch24Id.Text));
                    gecko.WriteShort(pouchpointer + 0x5E, Convert.ToInt16(CPouch24Amount.Text));
                }
            }

            //==========================================================================================
            //Get Gunner Pouch
            //Check to see if we're still on a quest
            playerpointer = gecko.GetUInt(0x2F41FAFC);

            if (playerpointer > 0x30000000)
            {
                //check to see if player is a gunner
                if (gpouchpointer > 0x30000000 && CBItemEnable.IsChecked == true)
                {
                    if (Convert.ToInt16(CGPouch1Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer, gecko.StringToByteArray(CGPouch1Id.Text));
                        gecko.WriteShort(gpouchpointer + 0x2, Convert.ToInt16(CGPouch1Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch2Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0x4, gecko.StringToByteArray(CGPouch2Id.Text));
                        gecko.WriteShort(gpouchpointer + 0x6, Convert.ToInt16(CGPouch2Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch3Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0x8, gecko.StringToByteArray(CGPouch3Id.Text));
                        gecko.WriteShort(gpouchpointer + 0xA, Convert.ToInt16(CGPouch3Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch4Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0xC, gecko.StringToByteArray(CGPouch4Id.Text));
                        gecko.WriteShort(gpouchpointer + 0xE, Convert.ToInt16(CGPouch4Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch5Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0x10, gecko.StringToByteArray(CGPouch5Id.Text));
                        gecko.WriteShort(gpouchpointer + 0x12, Convert.ToInt16(CGPouch5Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch6Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0x14, gecko.StringToByteArray(CGPouch6Id.Text));
                        gecko.WriteShort(gpouchpointer + 0x16, Convert.ToInt16(CGPouch6Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch7Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0x18, gecko.StringToByteArray(CGPouch7Id.Text));
                        gecko.WriteShort(gpouchpointer + 0x1A, Convert.ToInt16(CGPouch7Amount.Text));
                    }

                    if (Convert.ToInt16(CGPouch8Amount.Text) != 0)
                    {
                        gecko.WriteBytes(gpouchpointer + 0x1C, gecko.StringToByteArray(CGPouch8Id.Text));
                        gecko.WriteShort(gpouchpointer + 0x1E, Convert.ToInt16(CGPouch8Amount.Text));
                    }
                }
            }

            return true;

        }
        
        private void InitializeArrayDB()
        {
            //=================================================================
            //*****************************************************************
            //Equipment ID
            string path = System.IO.Directory.GetCurrentDirectory();

            System.IO.StreamReader EQFile = new System.IO.StreamReader(path + @"\Equipment_ID.txt");
            string EQLine1 = EQFile.ReadLine(); // gets the first line from file.
            EQFile.Close();

            string[] TmpArray = EQLine1.Split('=');

            var NumOfEntries = Convert.ToInt16(TmpArray[1]);

            Equipment_ID = new String[NumOfEntries,2];

            //Open the file again
            System.IO.StreamReader EQFile1 = new System.IO.StreamReader(path + @"\Equipment_ID.txt");

            string line;
            int i = 0;

            while ((line = EQFile1.ReadLine()) != null)
            {
                TmpArray = line.Split('=');
                Equipment_ID[i,0] = TmpArray[0].Trim();
                Equipment_ID[i,1] = TmpArray[1].Trim();
                
                if (i == 0)
                {
                    EQType.Items.Add("None");
                }
                else
                {
                    EQType.Items.Add(Equipment_ID[i, 1]);
                }

                i++;
            }
            EQFile1.Close();

            //=================================================================
            //*****************************************************************
            System.IO.StreamReader File = new System.IO.StreamReader(path + @"\Items.txt");
            string Line1 = File.ReadLine(); // gets the first line from file.
            File.Close();

            TmpArray = Line1.Split('=');

            NumOfEntries = Convert.ToInt16(TmpArray[1]);

            ItemNames = new String[NumOfEntries, 2];

            //Open the file again
            System.IO.StreamReader ItemFile1 = new System.IO.StreamReader(path + @"\Items.txt");

            i = 0;

            while ((line = ItemFile1.ReadLine()) != null)
            {
                TmpArray = line.Split('=');
                ItemNames[i, 0] = TmpArray[0].Trim();
                ItemNames[i, 1] = TmpArray[1].Trim();

                if (i == 0)
                {
                    ItemNameList.Items.Add("None");
                    //PItemNameList.Items.Add("None");
                }
                else
                {
                    ItemNameList.Items.Add(ItemNames[i, 1]);
                    //PItemNameList.Items.Add(ItemNames[i, 1]);
                }

                i++;
            }
            ItemFile1.Close();

            //=================================================================
            //*****************************************************************
            System.IO.StreamReader UFile = new System.IO.StreamReader(path + @"\UseItems.txt");
            string ULine1 = UFile.ReadLine(); // gets the first line from file.
            UFile.Close();

            TmpArray = ULine1.Split('=');

            NumOfEntries = Convert.ToInt16(TmpArray[1]);

            UItemNames = new String[NumOfEntries, 2];

            //Open the file again
            System.IO.StreamReader UItemFile1 = new System.IO.StreamReader(path + @"\UseItems.txt");

            i = 0;

            while ((line = UItemFile1.ReadLine()) != null)
            {
                TmpArray = line.Split('=');
                UItemNames[i, 0] = TmpArray[0].Trim();
                UItemNames[i, 1] = TmpArray[1].Trim();

                if (i == 0)
                {
                    PItemNameList.Items.Add("None");
                }
                else
                {
                    PItemNameList.Items.Add(UItemNames[i, 1]);
                }

                i++;
            }
            UItemFile1.Close();

            //=================================================================
            //*****************************************************************
            System.IO.StreamReader File2 = new System.IO.StreamReader(path + @"\Monsters.txt");
            string Line2 = File2.ReadLine(); // gets the first line from file.
            File2.Close();

            TmpArray = Line2.Split('=');

            NumOfEntries = Convert.ToInt16(TmpArray[1]);

            MonsterNames = new String[NumOfEntries, 2];

            //Open the file again
            System.IO.StreamReader MonsterFile2 = new System.IO.StreamReader(path + @"\Monsters.txt");

            i = 0;

            while ((line = MonsterFile2.ReadLine()) != null)
            {
                TmpArray = line.Split('=');
                MonsterNames[i, 0] = TmpArray[0].Trim();
                MonsterNames[i, 1] = TmpArray[1].Trim();
                               
                i++;
            }
            MonsterFile2.Close();

            //=================================================================
            //*****************************************************************
            System.IO.StreamReader File3 = new System.IO.StreamReader(path + @"\P_Skills.txt");
            string Line3 = File3.ReadLine(); // gets the first line from file.
            File3.Close();

            TmpArray = Line3.Split('=');

            NumOfEntries = Convert.ToInt16(TmpArray[1]);

            PlayerSkills = new String[NumOfEntries, 2];

            //Open the file again
            System.IO.StreamReader P_SkillsFile = new System.IO.StreamReader(path + @"\P_Skills.txt");

            i = 0;

            while ((line = P_SkillsFile.ReadLine()) != null)
            {
                TmpArray = line.Split('=');
                PlayerSkills[i, 0] = TmpArray[0].Trim();
                PlayerSkills[i, 1] = TmpArray[1].Trim();

                if (i == 0)
                {
                    ActiveSkill1.Items.Add("None");
                    ActiveSkill2.Items.Add("None");
                    ActiveSkill3.Items.Add("None");
                    ActiveSkill4.Items.Add("None");
                    ActiveSkill5.Items.Add("None");
                    ActiveSkill6.Items.Add("None");
                    ActiveSkill7.Items.Add("None");
                    ActiveSkill8.Items.Add("None");
                    ActiveSkill9.Items.Add("None");
                    ActiveSkill10.Items.Add("None");
                    
                }
                else
                {
                    ActiveSkill1.Items.Add(PlayerSkills[i, 1]);
                    ActiveSkill2.Items.Add(PlayerSkills[i, 1]);
                    ActiveSkill3.Items.Add(PlayerSkills[i, 1]);
                    ActiveSkill4.Items.Add(PlayerSkills[i, 1]);
                    ActiveSkill5.Items.Add(PlayerSkills[i, 1]);
                    ActiveSkill6.Items.Add(PlayerSkills[i, 1]);
                    ActiveSkill7.Items.Add(PlayerSkills[i, 1]);
                    ActiveSkill8.Items.Add(PlayerSkills[i, 1]);
                    ActiveSkill9.Items.Add(PlayerSkills[i, 1]);
                    ActiveSkill10.Items.Add(PlayerSkills[i, 1]);

                }

                i++;
            }
            P_SkillsFile.Close();

            //=================================================================
            //*****************************************************************
            System.IO.StreamReader File4 = new System.IO.StreamReader(path + @"\F_Skills.txt");
            string Line4 = File4.ReadLine(); // gets the first line from file.
            File4.Close();

            TmpArray = Line4.Split('=');

            NumOfEntries = Convert.ToInt16(TmpArray[1]);

            FoodSkills = new String[NumOfEntries, 2];

            //Open the file again
            System.IO.StreamReader F_SkillsFile = new System.IO.StreamReader(path + @"\F_Skills.txt");

            i = 0;

            while ((line = F_SkillsFile.ReadLine()) != null)
            {
                TmpArray = line.Split('=');
                FoodSkills[i, 0] = TmpArray[0].Trim();
                FoodSkills[i, 1] = TmpArray[1].Trim();

                if (i == 0)
                {
                    FoodSkillName1.Items.Add("None");
                    FoodSkillName2.Items.Add("None");
                    FoodSkillName3.Items.Add("None");
                }
                else
                {
                    FoodSkillName1.Items.Add(FoodSkills[i, 1]);
                    FoodSkillName2.Items.Add(FoodSkills[i, 1]);
                    FoodSkillName3.Items.Add(FoodSkills[i, 1]);
                }

                i++;
            }
            F_SkillsFile.Close();

            //=================================================================
            //*****************************************************************
            System.IO.StreamReader File5 = new System.IO.StreamReader(path + @"\Jewels.txt");
            string Line5 = File5.ReadLine(); // gets the first line from file.
            File5.Close();

            TmpArray = Line5.Split('=');

            NumOfEntries = Convert.ToInt16(TmpArray[1]);

            Jewels = new String[NumOfEntries, 2];

            //Open the file again
            System.IO.StreamReader JewelsFile = new System.IO.StreamReader(path + @"\Jewels.txt");

            i = 0;

            while ((line = JewelsFile.ReadLine()) != null)
            {
                TmpArray = line.Split('=');
                Jewels[i, 0] = TmpArray[0].Trim();
                Jewels[i, 1] = TmpArray[1].Trim();

                if (i == 0)
                {
                    JwlSP1.Items.Add("None");
                    JwlSP2.Items.Add("None");
                    JwlSP3.Items.Add("None");
                }
                else
                {
                    JwlSP1.Items.Add(Jewels[i, 1]);
                    JwlSP2.Items.Add(Jewels[i, 1]);
                    JwlSP3.Items.Add(Jewels[i, 1]);
                }

                i++;
            }
            JewelsFile.Close();

            //=================================================================
            //*****************************************************************
            System.IO.StreamReader File6 = new System.IO.StreamReader(path + @"\T_Skills.txt");
            string Line6 = File6.ReadLine(); // gets the first line from file.
            File6.Close();

            TmpArray = Line5.Split('=');

            NumOfEntries = Convert.ToInt16(TmpArray[1]);

            CharmSkills = new String[NumOfEntries, 2];

            //Open the file again
            System.IO.StreamReader CharmFile = new System.IO.StreamReader(path + @"\T_Skills.txt");

            i = 0;

            while ((line = CharmFile.ReadLine()) != null)
            {
                TmpArray = line.Split('=');
                CharmSkills[i, 0] = TmpArray[0].Trim();
                CharmSkills[i, 1] = TmpArray[1].Trim();

                if (i == 0)
                {
                    EQSkill2.Items.Add("None");
                }
                else
                {
                    EQSkill2.Items.Add(CharmSkills[i, 1]);
                }

                i++;
            }
            CharmFile.Close();

            //++++++++++++++++++++++++++++++++++++++++++++++++++
            //==================================================
            //Use Quest.txt data to fill in datagrid
            System.IO.StreamReader file99 = new System.IO.StreamReader(path + @"\Quest.txt");
            DataTable dt = new DataTable();
            
            //set up columns names
            dt.Columns.Add(new DataColumn("ID", typeof(string)));
            dt.Columns.Add(new DataColumn("HR", typeof(string)));
            dt.Columns.Add(new DataColumn("Quest", typeof(string)));
            dt.Columns.Add(new DataColumn("Map", typeof(string)));
            dt.Columns.Add(new DataColumn("Monster 1", typeof(string)));
            dt.Columns.Add(new DataColumn("Monster 2", typeof(string)));
            dt.Columns.Add(new DataColumn("Monster 3", typeof(string)));
            dt.Columns.Add(new DataColumn("Monster 4", typeof(string)));
            dt.Columns.Add(new DataColumn("Monster 5", typeof(string)));
            dt.Columns.Add(new DataColumn("Reward", typeof(string)));

            while ((line = file99.ReadLine()) != null)
            {
                DataRow dr = dt.NewRow();
                string[] TmpArrayDG = line.Split('|');
                for (i = 0; i < TmpArrayDG.Length; i++)
                {
                    string Test = TmpArrayDG[i];
                    dr[i] = TmpArrayDG[i];
                }
                dt.Rows.Add(dr);
            }
            file99.Close();
            QuestData.ItemsSource = dt.DefaultView;

            //++++++++++++++++++++++++++++++++++++++++++++++++++++
            //====================================================

        }

        //return array index of found item
        private int LookUpArrayID(string DataID, string[,] NameArray)
        {
            var ArrayLen = Convert.ToUInt16(NameArray[0,1]);

            for (int i = 0; i < ArrayLen; i++)
            {
                if (DataID == NameArray[i,0])
                { return i; }
            }

            return 0;
        }
        
        //return array index of found item
        private int LookUpArrayName(string Name, string[,] NameArray)
        {
            var ArrayLen = Convert.ToUInt16(NameArray[0, 1]);

            for (int i = 0; i < ArrayLen; i++)
            {
                if (Name == NameArray[i, 1])
                { return i; }
            }

            return 0;
        }
                
        private void EquipmentView(string Equipment, string SubType)
        {
            if (Equipment == "initialize")
            {
                LblSkill1.Visibility = Visibility.Hidden;
                LblAmt1.Visibility = Visibility.Hidden;
                LblSkill2.Visibility = Visibility.Hidden;
                LblAmt2.Visibility = Visibility.Hidden;
                LblRare.Visibility = Visibility.Hidden;
                LblSlots.Visibility = Visibility.Hidden;

                EQSkill1.Visibility = Visibility.Hidden;
                EQAmt1.Visibility = Visibility.Hidden;
                EQSkill2.Visibility = Visibility.Hidden;
                EQAmt2.Visibility = Visibility.Hidden;
                EQRare.Visibility = Visibility.Hidden;
                EQSlots.Visibility = Visibility.Hidden;

                LblJwlSp1.Visibility = Visibility.Hidden;
                LblJwlSp2.Visibility = Visibility.Hidden;
                LblJwlSp3.Visibility = Visibility.Hidden;

                JwlSP1.Visibility = Visibility.Hidden;
                JwlSP2.Visibility = Visibility.Hidden;
                JwlSP3.Visibility = Visibility.Hidden;
            }

            if (Equipment == "weapon")
            {
                LblSkill1.Content = "Name";
                LblSkill1.Visibility = Visibility.Visible;

                LblAmt1.Visibility = Visibility.Hidden;
                LblSkill2.Visibility = Visibility.Hidden;
                LblAmt2.Visibility = Visibility.Hidden;
                LblRare.Visibility = Visibility.Hidden;
                LblSlots.Visibility = Visibility.Hidden;

                EQSkill1.Visibility = Visibility.Visible;
                EQAmt1.Visibility = Visibility.Hidden;
                EQSkill2.Visibility = Visibility.Hidden;
                EQAmt2.Visibility = Visibility.Hidden;
                EQRare.Visibility = Visibility.Hidden;
                EQSlots.Visibility = Visibility.Hidden;

                //LblJwlSp1.Visibility = Visibility.Visible;
                //LblJwlSp2.Visibility = Visibility.Visible;
                //LblJwlSp3.Visibility = Visibility.Visible;

                //JwlSP1.Visibility = Visibility.Visible;
                //JwlSP2.Visibility = Visibility.Visible;
                //JwlSP3.Visibility = Visibility.Visible;
            }

            if (Equipment == "armor")
            {
                LblSkill1.Content = "Name";
                LblSkill1.Visibility = Visibility.Visible;

                LblAmt1.Content = "Level";
                LblAmt1.Visibility = Visibility.Visible;

                EQSkill1.Visibility = Visibility.Visible;
                EQAmt1.Visibility = Visibility.Visible;

                LblSkill2.Visibility = Visibility.Hidden;
                LblAmt2.Visibility = Visibility.Hidden;
                                
                EQSkill2.Visibility = Visibility.Hidden;
                EQAmt2.Visibility = Visibility.Hidden;

                LblRare.Visibility = Visibility.Hidden;
                LblSlots.Visibility = Visibility.Hidden;

                EQRare.Visibility = Visibility.Hidden;
                EQSlots.Visibility = Visibility.Hidden;

                if (SubType == Equipment_ID[5, 1])
                {
                    //LblJwlSp1.Visibility = Visibility.Visible;
                    //LblJwlSp2.Visibility = Visibility.Visible;
                    //LblJwlSp3.Visibility = Visibility.Visible;

                    //JwlSP1.Visibility = Visibility.Visible;
                    //JwlSP2.Visibility = Visibility.Visible;
                    //JwlSP3.Visibility = Visibility.Visible;
                                        
                }
                else
                {
                    //LblJwlSp1.Visibility = Visibility.Visible;
                    LblJwlSp2.Visibility = Visibility.Hidden;
                    LblJwlSp3.Visibility = Visibility.Hidden;

                    //JwlSP1.Visibility = Visibility.Visible;
                    JwlSP2.Visibility = Visibility.Hidden;
                    JwlSP3.Visibility = Visibility.Hidden;
                                       
                }
            }

            if (Equipment == "talisman")
            {
                LblSkill1.Content = "Skill 1";
                LblSkill1.Visibility = Visibility.Visible;

                LblAmt1.Content = "Points";
                LblAmt1.Visibility = Visibility.Visible;

                LblSkill2.Content = "Skill 2";
                LblSkill2.Visibility = Visibility.Visible ;

                LblAmt2.Content = "Points";
                LblAmt2.Visibility = Visibility.Visible;

                LblRare.Visibility = Visibility.Visible;
                LblSlots.Visibility = Visibility.Visible;

                EQSkill1.Visibility = Visibility.Visible;
                EQAmt1.Visibility = Visibility.Visible;
                EQSkill2.Visibility = Visibility.Visible ;
                EQAmt2.Visibility = Visibility.Visible;

                EQRare.Visibility = Visibility.Visible;
                EQSlots.Visibility = Visibility.Visible;

                //LblJwlSp1.Visibility = Visibility.Visible;
                //LblJwlSp2.Visibility = Visibility.Visible;
                //LblJwlSp3.Visibility = Visibility.Visible;

                //JwlSP1.Visibility = Visibility.Visible;
                //JwlSP2.Visibility = Visibility.Visible;
                //JwlSP3.Visibility = Visibility.Visible;
                               
            }

        }

        private void AllNumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            var regex = new Regex("[^0-9-]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            var regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void ReplicateClick(object sender, RoutedEventArgs e)
        {
            string ButtonState = Convert.ToString(Replicator.Content);

            if (ButtonState == "Stop")
            {
                Replicator.Content = "Run";
                SetTimer("OFF");
                Capture.IsEnabled = true;
                Write.IsEnabled = true;
                ReadSkills.IsEnabled = true;
                WriteSkills.IsEnabled = true;
                return;
            }

            var playerpointer = gecko.GetUInt(0x2F41FAFC);

            if (playerpointer == 0x0 || playerpointer < 0x30000000)
            {
                //Player is probably not on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.Yes)
                {
                    MessageBox.Show("Error: Player data not found! You need to press \"-\" button on the gamepad ones to show player menu. Then try again.", playerpointer.ToString("X4"));
                    Replicator.Content = "Run";
                    SetTimer("OFF");
                    Capture.IsEnabled = true;
                    Write.IsEnabled = true;
                    ReadSkills.IsEnabled = true;
                    WriteSkills.IsEnabled = true;
                    return;
                }
                else if (dialog == MessageBoxResult.No)
                {
                    MessageBox.Show("Error: You need to be on a quest or outside the village to use this feature. Then try again.", playerpointer.ToString("X4"));
                    Replicator.Content = "Run";
                    SetTimer("OFF");
                    Capture.IsEnabled = true;
                    Write.IsEnabled = true;
                    ReadSkills.IsEnabled = true;
                    WriteSkills.IsEnabled = true;
                    return;
                }
            }
            else if (playerpointer > 0x30000000)
            {
                //Player is on a quest
                // was going to do a capture first, but realize it gets in the way of game play.
                //CaptureClick(sender, e);

                MessageBoxResult dialog = MessageBox.Show("Start Timer for Replicator?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.No)
                {
                    MessageBox.Show("Replicator will NOT start. Then try again.", playerpointer.ToString("X4"));
                    Replicator.Content = "Run";
                    SetTimer("OFF");
                    Capture.IsEnabled = true;
                    Write.IsEnabled = true;
                    ReadSkills.IsEnabled = true;
                    WriteSkills.IsEnabled = true;
                    return;
                }

                //Should be doing a skill write here by call a button

                //Call the replicator routine so it kicks in immeadately
                bool Temp = WriteReplicateData();
                WCounter = 1; //need to set to 1 and not zero because we're writing now
                WTotCounter = 1;
                DisplayWCounter.Text = Convert.ToString(WTotCounter);

                if (Temp == false)
                {
                    //something has gone wrong, must shut off replicator
                    Replicator.Content = "Run";
                    SetTimer("OFF");
                    Capture.IsEnabled = true;
                    Write.IsEnabled = true;
                    ReadSkills.IsEnabled = true;
                    WriteSkills.IsEnabled = true;
                    return;
                }

                Temp = ReadReplicateData();
                RCounter = 1; //need to set to 1 and not zero because we're reading now
                RTotCounter = 1;
                DisplayRCounter.Text = Convert.ToString(RTotCounter);

                if (Temp == false)
                {
                    //something has gone wrong, must shut off replicator
                    Replicator.Content = "Run";
                    SetTimer("OFF");
                    Capture.IsEnabled = true;
                    Write.IsEnabled = true;
                    ReadSkills.IsEnabled = true;
                    WriteSkills.IsEnabled = true;
                    return;
                }

                //Now start the replicator
                Replicator.Content = "Stop";
                SetTimer("ON");
                Capture.IsEnabled = false;
                Write.IsEnabled = false;
                ReadSkills.IsEnabled = false;
                WriteSkills.IsEnabled = false;
                return;
                    
            }
            else
            {
                MessageBox.Show("Player data invalid. You need to be on a Quest.", playerpointer.ToString("X4"));
                Replicator.Content = "Run";
                SetTimer("OFF");
                Capture.IsEnabled = true;
                Write.IsEnabled = true;
                ReadSkills.IsEnabled = true;
                WriteSkills.IsEnabled = true;
                return;
            }
        }
                
        private void CaptureClick(object sender, RoutedEventArgs e)
        {
            //check to see if Write button has been enable
            if (Write.IsEnabled == false)
            { Write.IsEnabled = true; }

            if (Write.IsEnabled == true && WriteSkills.IsEnabled == true)
            { Replicator.IsEnabled = true; }

            //===============================================
            byte[] pouchData = null;
            byte[] gpouchData = null;

            var playerpointer = gecko.GetUInt(0x2F41FAFC);
            //MessageBox.Show(playerpointer.ToString("X4"));

            //Just initialize the variable here and assume not on quest
            var pouchpointer = Convert.ToUInt32(0x0);
            var gpouchpointer = Convert.ToUInt32(0x0);

            if (playerpointer != 0x0 && playerpointer < 0x30000000)
            {
                //Player is probably not on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo,MessageBoxImage.Information);
                if (dialog == MessageBoxResult.Yes)
                {
                    MessageBox.Show("Error: Player data not found! You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                    return;

                }

                //Get Blade Pouch Position
                pouchpointer = gecko.GetUInt(0x2F41FAFC);
                //Read Blade Pouch Data
                pouchData = gecko.ReadBytes(pouchpointer, 0x80);

                //Get Gunner Pouch Position
                gpouchpointer = gecko.GetUInt(0x2F41FB00);
                //Note: Cannot read here in case of player is a blademaster
                //resulting in a zero pointer
                //Read Gunner Pouch Data
                //gpouchData = gecko.ReadBytes(gpouchpointer, 0x20);
                                
            }
            else if (playerpointer > 0x30000000)
            {
                //Player is on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.No)
                {
                    MessageBox.Show("Error has occur! Game thinks you're on a quest. You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                    return;

                }

                //Get Health, Stamina, Air,etc
                var playeraddress = playerpointer + 0x168;
                var playerdata = gecko.ReadBytes(playeraddress, 0x20);

                var health1 = BitConverter.ToInt16(playerdata.Skip(0).Take(2).Reverse().ToArray(), 0);
                var health2 = BitConverter.ToInt16(playerdata.Skip(2).Take(2).Reverse().ToArray(), 0);
                CHealth1.Text = health1.ToString();
                CHealth2.Text = health2.ToString();

                //This is the redhealth, therefore it's swap in the textbox
                var u1 = BitConverter.ToInt16(playerdata.Skip(4).Take(2).Reverse().ToArray(), 0);
                var u2 = BitConverter.ToInt16(playerdata.Skip(6).Take(2).Reverse().ToArray(), 0);
                CU1.Text = u1.ToString();
                CU2.Text = u2.ToString();

                var stam1 = BitConverter.ToSingle(playerdata.Skip(8).Take(4).Reverse().ToArray(), 0);
                var stam2 = BitConverter.ToSingle(playerdata.Skip(12).Take(4).Reverse().ToArray(), 0);
                Win1.CStamina1.Text = Math.Round(stam1, 0).ToString();
                Win1.CStamina2.Text = Math.Round(stam2, 0).ToString();

                var count1 = BitConverter.ToSingle(playerdata.Skip(16).Take(4).Reverse().ToArray(), 0);
                var count2 = BitConverter.ToSingle(playerdata.Skip(20).Take(4).Reverse().ToArray(), 0);
                Win1.CCountdown1.Text = Math.Round(count1, 0).ToString();
                Win1.CCountdown2.Text = Math.Round(count2, 0).ToString();

                var air1 = BitConverter.ToInt16(playerdata.Skip(28).Take(2).Reverse().ToArray(), 0);
                var air2 = BitConverter.ToInt16(playerdata.Skip(30).Take(2).Reverse().ToArray(), 0);
                Win1.CAir1.Text = air1.ToString();
                Win1.CAir2.Text = air2.ToString();
                                
                //---------------------------------------------------------------------------------
                //Get Blade Pouch Position
                pouchpointer = gecko.GetUInt(0x2F41FAFC);
                //Read Blade Pouch Data
                pouchData = gecko.ReadBytes(pouchpointer, 0x80);

                //Get Gunner Pouch Position
                gpouchpointer = gecko.GetUInt(0x2F41FB00);
                //Note: Cannot read here in case of player is a blademaster
                //resulting in a zero pointer
                //Read Gunner Pouch Data
                //gpouchData = gecko.ReadBytes(gpouchpointer, 0x20);
            }
            else
            {
                MessageBox.Show("Player data invalid. You need to press \"-\" button on the gamepad to show player menu. Then try again.",playerpointer.ToString("X4"));
                return;
            }

            //==========================================================================================
            //Get Blade Pouch
            //check to see if pouch is empty,if so then exit
            if (pouchData == null || pouchData.Length == 0)
            {
                CPouch1Id.Text = "0000";
                CPouch2Id.Text = "0000";
                CPouch3Id.Text = "0000";
                CPouch4Id.Text = "0000";
                CPouch5Id.Text = "0000";
                CPouch6Id.Text = "0000";
                CPouch7Id.Text = "0000";
                CPouch8Id.Text = "0000";
                CPouch9Id.Text = "0000";
                CPouch10Id.Text = "0000";
                CPouch11Id.Text = "0000";
                CPouch12Id.Text = "0000";
                CPouch13Id.Text = "0000";
                CPouch14Id.Text = "0000";
                CPouch15Id.Text = "0000";
                CPouch16Id.Text = "0000";
                CPouch17Id.Text = "0000";
                CPouch18Id.Text = "0000";
                CPouch19Id.Text = "0000";
                CPouch20Id.Text = "0000";
                CPouch21Id.Text = "0000";
                CPouch22Id.Text = "0000";
                CPouch23Id.Text = "0000";
                CPouch24Id.Text = "0000";
                return;
            }

            int TempID;

            CPouch1Id.Text = BitConverter.ToString(pouchData.Skip(0).Take(2).ToArray()).Replace("-", "");
            CPouch1Amount.Text = BitConverter.ToInt16(pouchData.Skip(2).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch1Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch1Id.Text, ItemNames);
                CPouch1Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch1Name.Text = "";}

            CPouch2Id.Text = BitConverter.ToString(pouchData.Skip(4).Take(2).ToArray()).Replace("-", "");
            CPouch2Amount.Text = BitConverter.ToInt16(pouchData.Skip(6).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch2Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch2Id.Text, ItemNames);
                CPouch2Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch2Name.Text = ""; }

            CPouch3Id.Text = BitConverter.ToString(pouchData.Skip(8).Take(2).ToArray()).Replace("-", "");
            CPouch3Amount.Text = BitConverter.ToInt16(pouchData.Skip(10).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch3Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch3Id.Text, ItemNames);
                CPouch3Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch3Name.Text = ""; }

            CPouch4Id.Text = BitConverter.ToString(pouchData.Skip(12).Take(2).ToArray()).Replace("-", "");
            CPouch4Amount.Text = BitConverter.ToInt16(pouchData.Skip(14).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch4Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch4Id.Text, ItemNames);
                CPouch4Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch4Name.Text = ""; }

            CPouch5Id.Text = BitConverter.ToString(pouchData.Skip(16).Take(2).ToArray()).Replace("-", "");
            CPouch5Amount.Text = BitConverter.ToInt16(pouchData.Skip(18).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch5Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch5Id.Text, ItemNames);
                CPouch5Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch5Name.Text = ""; }

            CPouch6Id.Text = BitConverter.ToString(pouchData.Skip(20).Take(2).ToArray()).Replace("-", "");
            CPouch6Amount.Text = BitConverter.ToInt16(pouchData.Skip(22).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch6Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch6Id.Text, ItemNames);
                CPouch6Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch6Name.Text = ""; }

            CPouch7Id.Text = BitConverter.ToString(pouchData.Skip(24).Take(2).ToArray()).Replace("-", "");
            CPouch7Amount.Text = BitConverter.ToInt16(pouchData.Skip(26).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch7Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch7Id.Text, ItemNames);
                CPouch7Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch7Name.Text = ""; }

            CPouch8Id.Text = BitConverter.ToString(pouchData.Skip(28).Take(2).ToArray()).Replace("-", "");
            CPouch8Amount.Text = BitConverter.ToInt16(pouchData.Skip(30).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch8Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch8Id.Text, ItemNames);
                CPouch8Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch8Name.Text = ""; }

            CPouch9Id.Text = BitConverter.ToString(pouchData.Skip(32).Take(2).ToArray()).Replace("-", "");
            CPouch9Amount.Text = BitConverter.ToInt16(pouchData.Skip(34).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch9Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch9Id.Text, ItemNames);
                CPouch9Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch9Name.Text = ""; }

            CPouch10Id.Text = BitConverter.ToString(pouchData.Skip(36).Take(2).ToArray()).Replace("-", "");
            CPouch10Amount.Text = BitConverter.ToInt16(pouchData.Skip(38).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch10Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch10Id.Text, ItemNames);
                CPouch10Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch10Name.Text = ""; }

            CPouch11Id.Text = BitConverter.ToString(pouchData.Skip(40).Take(2).ToArray()).Replace("-", "");
            CPouch11Amount.Text = BitConverter.ToInt16(pouchData.Skip(42).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch11Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch11Id.Text, ItemNames);
                CPouch11Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch11Name.Text = ""; }

            CPouch12Id.Text = BitConverter.ToString(pouchData.Skip(44).Take(2).ToArray()).Replace("-", "");
            CPouch12Amount.Text = BitConverter.ToInt16(pouchData.Skip(46).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch12Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch12Id.Text, ItemNames);
                CPouch12Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch12Name.Text = ""; }

            CPouch13Id.Text = BitConverter.ToString(pouchData.Skip(48).Take(2).ToArray()).Replace("-", "");
            CPouch13Amount.Text = BitConverter.ToInt16(pouchData.Skip(50).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch13Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch13Id.Text, ItemNames);
                CPouch13Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch13Name.Text = ""; }

            CPouch14Id.Text = BitConverter.ToString(pouchData.Skip(52).Take(2).ToArray()).Replace("-", "");
            CPouch14Amount.Text = BitConverter.ToInt16(pouchData.Skip(54).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch14Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch14Id.Text, ItemNames);
                CPouch14Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch14Name.Text = ""; }

            CPouch15Id.Text = BitConverter.ToString(pouchData.Skip(56).Take(2).ToArray()).Replace("-", "");
            CPouch15Amount.Text = BitConverter.ToInt16(pouchData.Skip(58).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch15Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch15Id.Text, ItemNames);
                CPouch15Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch15Name.Text = ""; }

            CPouch16Id.Text = BitConverter.ToString(pouchData.Skip(60).Take(2).ToArray()).Replace("-", "");
            CPouch16Amount.Text = BitConverter.ToInt16(pouchData.Skip(62).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch16Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch16Id.Text, ItemNames);
                CPouch16Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch16Name.Text = ""; }

            CPouch17Id.Text = BitConverter.ToString(pouchData.Skip(64).Take(2).ToArray()).Replace("-", "");
            CPouch17Amount.Text = BitConverter.ToInt16(pouchData.Skip(66).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch17Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch17Id.Text, ItemNames);
                CPouch17Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch17Name.Text = ""; }

            CPouch18Id.Text = BitConverter.ToString(pouchData.Skip(68).Take(2).ToArray()).Replace("-", "");
            CPouch18Amount.Text = BitConverter.ToInt16(pouchData.Skip(70).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch18Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch18Id.Text, ItemNames);
                CPouch18Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch18Name.Text = ""; }

            CPouch19Id.Text = BitConverter.ToString(pouchData.Skip(72).Take(2).ToArray()).Replace("-", "");
            CPouch19Amount.Text = BitConverter.ToInt16(pouchData.Skip(74).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch19Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch19Id.Text, ItemNames);
                CPouch19Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch19Name.Text = ""; }

            CPouch20Id.Text = BitConverter.ToString(pouchData.Skip(76).Take(2).ToArray()).Replace("-", "");
            CPouch20Amount.Text = BitConverter.ToInt16(pouchData.Skip(78).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch20Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch20Id.Text, ItemNames);
                CPouch20Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch20Name.Text = ""; }

            CPouch21Id.Text = BitConverter.ToString(pouchData.Skip(80).Take(2).ToArray()).Replace("-", "");
            CPouch21Amount.Text = BitConverter.ToInt16(pouchData.Skip(82).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch21Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch21Id.Text, ItemNames);
                CPouch21Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch21Name.Text = ""; }

            CPouch22Id.Text = BitConverter.ToString(pouchData.Skip(84).Take(2).ToArray()).Replace("-", "");
            CPouch22Amount.Text = BitConverter.ToInt16(pouchData.Skip(86).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch22Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch22Id.Text, ItemNames);
                CPouch22Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch22Name.Text = ""; }

            CPouch23Id.Text = BitConverter.ToString(pouchData.Skip(88).Take(2).ToArray()).Replace("-", "");
            CPouch23Amount.Text = BitConverter.ToInt16(pouchData.Skip(90).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch23Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch23Id.Text, ItemNames);
                CPouch23Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch23Name.Text = ""; }

            CPouch24Id.Text = BitConverter.ToString(pouchData.Skip(92).Take(2).ToArray()).Replace("-", "");
            CPouch24Amount.Text = BitConverter.ToInt16(pouchData.Skip(94).Take(2).Reverse().ToArray(), 0).ToString();
            if (CPouch24Id.Text != "0000")
            {
                TempID = LookUpArrayID(CPouch24Id.Text, ItemNames);
                CPouch24Name.Text = ItemNames[TempID, 1];
            }
            else { CPouch24Name.Text = ""; }

            //==========================================================================================
            //Get Gunner Pouch
            //check to see if player is a gunner
            //if (gpouchpointer > 0x30000000)
            if (gpouchpointer != 0)
            {
                //Read Gunner Pouch Data
                gpouchData = gecko.ReadBytes(gpouchpointer, 0x20);

                CGPouch1Id.Text = BitConverter.ToString(gpouchData.Skip(0).Take(2).ToArray()).Replace("-", "");
                CGPouch1Amount.Text = BitConverter.ToInt16(gpouchData.Skip(2).Take(2).Reverse().ToArray(), 0).ToString();
                if (CGPouch1Id.Text != "0000")
                {
                    TempID = LookUpArrayID(CGPouch1Id.Text, ItemNames);
                    CGPouch1Name.Text = ItemNames[TempID, 1];
                }
                else { CGPouch1Name.Text = ""; }

                CGPouch2Id.Text = BitConverter.ToString(gpouchData.Skip(4).Take(2).ToArray()).Replace("-", "");
                CGPouch2Amount.Text = BitConverter.ToInt16(gpouchData.Skip(6).Take(2).Reverse().ToArray(), 0).ToString();
                if (CGPouch2Id.Text != "0000")
                {
                    TempID = LookUpArrayID(CGPouch2Id.Text, ItemNames);
                    CGPouch2Name.Text = ItemNames[TempID, 1];
                }
                else { CGPouch2Name.Text = ""; }

                CGPouch3Id.Text = BitConverter.ToString(gpouchData.Skip(8).Take(2).ToArray()).Replace("-", "");
                CGPouch3Amount.Text = BitConverter.ToInt16(gpouchData.Skip(10).Take(2).Reverse().ToArray(), 0).ToString();
                if (CGPouch3Id.Text != "0000")
                {
                    TempID = LookUpArrayID(CGPouch3Id.Text, ItemNames);
                    CGPouch3Name.Text = ItemNames[TempID, 1];
                }
                else { CGPouch3Name.Text = ""; }

                CGPouch4Id.Text = BitConverter.ToString(gpouchData.Skip(12).Take(2).ToArray()).Replace("-", "");
                CGPouch4Amount.Text = BitConverter.ToInt16(gpouchData.Skip(14).Take(2).Reverse().ToArray(), 0).ToString();
                if (CGPouch4Id.Text != "0000")
                {
                    TempID = LookUpArrayID(CGPouch4Id.Text, ItemNames);
                    CGPouch4Name.Text = ItemNames[TempID, 1];
                }
                else { CGPouch4Name.Text = ""; }

                CGPouch5Id.Text = BitConverter.ToString(gpouchData.Skip(16).Take(2).ToArray()).Replace("-", "");
                CGPouch5Amount.Text = BitConverter.ToInt16(gpouchData.Skip(18).Take(2).Reverse().ToArray(), 0).ToString();
                if (CGPouch5Id.Text != "0000")
                {
                    TempID = LookUpArrayID(CGPouch5Id.Text, ItemNames);
                    CGPouch5Name.Text = ItemNames[TempID, 1];
                }
                else { CGPouch5Name.Text = ""; }

                CGPouch6Id.Text = BitConverter.ToString(gpouchData.Skip(20).Take(2).ToArray()).Replace("-", "");
                CGPouch6Amount.Text = BitConverter.ToInt16(gpouchData.Skip(22).Take(2).Reverse().ToArray(), 0).ToString();
                if (CGPouch6Id.Text != "0000")
                {
                    TempID = LookUpArrayID(CGPouch6Id.Text, ItemNames);
                    CGPouch6Name.Text = ItemNames[TempID, 1];
                }
                else { CGPouch6Name.Text = ""; }

                CGPouch7Id.Text = BitConverter.ToString(gpouchData.Skip(24).Take(2).ToArray()).Replace("-", "");
                CGPouch7Amount.Text = BitConverter.ToInt16(gpouchData.Skip(26).Take(2).Reverse().ToArray(), 0).ToString();
                if (CGPouch7Id.Text != "0000")
                {
                    TempID = LookUpArrayID(CGPouch7Id.Text, ItemNames);
                    CGPouch7Name.Text = ItemNames[TempID, 1];
                }
                else { CGPouch7Name.Text = ""; }

                CGPouch8Id.Text = BitConverter.ToString(gpouchData.Skip(28).Take(2).ToArray()).Replace("-", "");
                CGPouch8Amount.Text = BitConverter.ToInt16(gpouchData.Skip(30).Take(2).Reverse().ToArray(), 0).ToString();
                if (CGPouch8Id.Text != "0000")
                {
                    TempID = LookUpArrayID(CGPouch8Id.Text, ItemNames);
                    CGPouch8Name.Text = ItemNames[TempID, 1];
                }
                else { CGPouch8Name.Text = ""; }
            }
            return;
        }

        private void WriteClick(object sender, RoutedEventArgs e)
        {
            uint EnableValue = 0x00007F7F;
            uint DisableValue = 0x00000000;
            uint MaxValue = 0x7FFF7FFF;
            //Floating point
            uint InfiniteValue = 0x50000000;

            var playerpointer = gecko.GetUInt(0x2F41FAFC);

            //Just initialize the variable here and assume not on quest
            var pouchpointer = Convert.ToUInt32(0x0);
            var gpouchpointer = Convert.ToUInt32(0x0);

            //MessageBox.Show(playerpointer.ToString("X4"));

            if (playerpointer != 0x0 && playerpointer < 0x30000000)
            {
                //Player is probably not on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.Yes)
                {
                    MessageBox.Show("Error: Player data not found! You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                    return;

                }

                //Get Blade Pouch Position
                pouchpointer = gecko.GetUInt(0x2F41FAFC);
                //Read Blade Pouch Data
                //pouchData = gecko.ReadBytes(pouchpointer, 0x80);

                //Get Gunner Pouch Position
                gpouchpointer = gecko.GetUInt(0x2F41FB00);
                //Read Gunner Pouch Data
                //gpouchData = gecko.ReadBytes(gpouchpointer, 0x20);
            }
            else if (playerpointer > 0x30000000)
            {
                //Player is on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.No)
                {
                    MessageBox.Show("Error has occur! Game thinks you're on a quest. You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                    return;

                }

                //---------------------------------------------------------------------------------
                //Get Blade Pouch Position
                pouchpointer = gecko.GetUInt(0x2F41FAFC);
                //Read Blade Pouch Data
                //pouchData = gecko.ReadBytes(pouchpointer, 0x80);

                //Get Gunner Pouch Position
                gpouchpointer = gecko.GetUInt(0x2F41FB00);
                //Read Gunner Pouch Data
                //gpouchData = gecko.ReadBytes(gpouchpointer, 0x20);

                //Get Health, Stamina, Air,etc
                var playeraddress = playerpointer + 0x168;

                if (CBGHealth.IsChecked == true)
                {
                    var health1 = Convert.ToInt16(CHealth1.Text);
                    var health2 = Convert.ToInt16(CHealth2.Text);
                    gecko.WriteShort(playeraddress, health1);
                    gecko.WriteShort(playeraddress + 0x2, health2);
                }

                if (CBRHealth.IsChecked == true)
                {
                    //This is the redhealth, therefore it's swap in the textbox
                    var u1 = Convert.ToInt16(CU1.Text);
                    var u2 = Convert.ToInt16(CU2.Text);
                    gecko.WriteShort(playeraddress + 0x4, u1);
                    gecko.WriteShort(playeraddress + 0x6, u2);
                }

                if (Win1.CBCStamina.IsChecked == true)
                {
                    var stam1 = Convert.ToSingle(Win1.CStamina1.Text);
                    var stam2 = Convert.ToSingle(Win1.CStamina2.Text);
                    gecko.WriteFloat(playeraddress + 0x8, stam1);
                    gecko.WriteFloat(playeraddress + 0xC, stam2);
                }

                if (Win1.CBCCountdown.IsChecked == true)
                {
                    var count1 = Convert.ToSingle(Win1.CCountdown1.Text);
                    var count2 = Convert.ToSingle(Win1.CCountdown2.Text);
                    gecko.WriteFloat(playeraddress + 0x10, count1);
                    gecko.WriteFloat(playeraddress + 0x14, count2);
                }

                if (Win1.CBCAir.IsChecked == true)
                {
                    var air1 = Convert.ToInt16(Win1.CAir1.Text);
                    var air2 = Convert.ToInt16(Win1.CAir2.Text);
                    gecko.WriteShort(playeraddress + 0x1C, air1);
                    gecko.WriteShort(playeraddress + 0x1E, air2);
                }
                                
                //=======================================
                //Increase all attack up buffs
                if (Win1.CBAttackUp.IsChecked == true)
                {
                    var AttackUpStr = EnableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x414, gecko.StringToByteArray(AttackUpStr));

                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x418, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x454, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x70C, gecko.StringToByteArray(InfiniteValueStr));
                }
                
                //Increase defense up
                if (Win1.CBDefenseUp.IsChecked == true)
                {
                    var DefenseUpStr = Convert.ToSingle(Win1.AddDefenseUp.Text);
                    gecko.WriteFloat(playerpointer + 0x428, DefenseUpStr);

                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x42C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x718, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Invincibility
                if (Win1.CBInvincible.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x1A8, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x1AC, gecko.StringToByteArray(InfiniteValueStr));

                    //write it again to make sure values stay
                    gecko.WriteBytes(playerpointer + 0x1A8, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x1AC, gecko.StringToByteArray(InfiniteValueStr));
                }

                //=======================================
                //Negate Stun
                if (Win1.CBNegateStun.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x790, gecko.StringToByteArray(InfiniteValueStr));

                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x294, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Poison 
                if (Win1.CBNegatePoison.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x24C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Paralysis
                if (Win1.CBNegateParalysis.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x79C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Negate Tremor/Quake
                if (Win1.CBNegateQuake.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x7A8, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Negate Muddy 
                if (Win1.CBNegateMuddy.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x32C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Snow/Ice 
                if (Win1.CBNegateSnow.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x31C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Soiled/Stench 
                if (Win1.CBNegateSnow.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x408, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Wind
                if (Win1.CBNegateWind.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x730, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x43C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Negate Defense Down 
                if (Win1.CBNegateDefDown.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x33C, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Elemental Down 
                if (Win1.CBNegateEleDown.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x348, gecko.StringToByteArray(DisableValueStr));
                    gecko.WriteBytes(playerpointer + 0x358, gecko.StringToByteArray(DisableValueStr));
                    gecko.WriteBytes(playerpointer + 0x368, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Slime  
                if (Win1.CBNegateSlime.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x2AC, gecko.StringToByteArray(DisableValueStr));
                }

                //Negate Fire Blight/Negate All Blight 
                if (Win1.CBNegateFire.IsChecked == true)
                {
                    var DisableValueStr = DisableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x234, gecko.StringToByteArray(DisableValueStr));
                }

                //======================================================
                //Elemental Atk Up
                if (Win1.CBElementalUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x7B4, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Status Atk Up
                if (Win1.CBStatusUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x814, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Purple Sharpness/Increase Sharpness
                if (Win1.CBPurpleSharp.IsChecked == true)
                {
                    var MaxValueStr = MaxValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x624, gecko.StringToByteArray(MaxValueStr));
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x454, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Affinity Up
                if (Win1.CBAffinityUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x808, gecko.StringToByteArray(InfiniteValueStr));
                }

                //HG Earplug
                if (Win1.CBHearing.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x784, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Mega Dash
                if (Win1.CBMegaDash.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x30C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x73C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Move Speed Up / Minds Eye
                if (Win1.CBSpeedUp.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x700, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Tracker / Show Monster
                if (Win1.CBTracker.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x748, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Hot Cancel / Heat Resist
                if (Win1.CBHotCancel.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x49C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x778, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Cold Cancel / Cold Resist
                if (Win1.CBColdCancel.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x4A8, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x76C, gecko.StringToByteArray(InfiniteValueStr));
                }

                //LS, DB Instant Charge
                if (Win1.CBCharge.IsChecked == true)
                {
                    //LS
                    var EnableValueStr = EnableValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x194, gecko.StringToByteArray(EnableValueStr));
                    //DB
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x484, gecko.StringToByteArray(InfiniteValueStr));
                    //SA
                    var SAFullCharge = "00640000";
                    gecko.WriteBytes(playerpointer + 0x154, gecko.StringToByteArray(SAFullCharge));
                    //GS
                    //var GSFullCharge = "03030000";
                    //gecko.WriteBytes(playerpointer + 0xAC, gecko.StringToByteArray(GSFullCharge));
                    //Bow
                    //var BowFullCharge = "42A2389B";
                    //gecko.WriteBytes(playerpointer + 0xA0, gecko.StringToByteArray(BowFullCharge));
                    //HM
                    //var HMFullCharge = "42A2389B";
                    //gecko.WriteBytes(playerpointer + 0xA4, gecko.StringToByteArray(HMFullCharge));
                }

                //Dragon Resist
                if (Win1.CBDragonRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x3A4, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3E0, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7F0, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Fire Resist
                if (Win1.CBFireRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x374, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3B0, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7C0, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Water Resist
                if (Win1.CBWaterRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x380, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3BC, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7CC, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Thunder Resist
                if (Win1.CBThunderRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x38C, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3C8, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7D8, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

                //Ice Resist
                if (Win1.CBIceRes.IsChecked == true)
                {
                    var InfiniteValueStr = InfiniteValue.ToString("X8");
                    gecko.WriteBytes(playerpointer + 0x398, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x3D4, gecko.StringToByteArray(InfiniteValueStr));
                    gecko.WriteBytes(playerpointer + 0x7E4, gecko.StringToByteArray(InfiniteValueStr));
                    //gecko.WriteBytes(playerpointer + 0x820, gecko.StringToByteArray(InfiniteValueStr));
                }

            }
            else
            {
                MessageBox.Show("Player data invalid. You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                return;
            }

            //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            //==========================================================================================
            //Write Blade Pouch
            if (CBItemEnable.IsChecked == true)
            {
                gecko.WriteBytes(pouchpointer, gecko.StringToByteArray(CPouch1Id.Text));
                gecko.WriteShort(pouchpointer + 0x2, Convert.ToInt16(CPouch1Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x4, gecko.StringToByteArray(CPouch2Id.Text));
                gecko.WriteShort(pouchpointer + 0x6, Convert.ToInt16(CPouch2Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x8, gecko.StringToByteArray(CPouch3Id.Text));
                gecko.WriteShort(pouchpointer + 0xA, Convert.ToInt16(CPouch3Amount.Text));

                gecko.WriteBytes(pouchpointer + 0xC, gecko.StringToByteArray(CPouch4Id.Text));
                gecko.WriteShort(pouchpointer + 0xE, Convert.ToInt16(CPouch4Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x10, gecko.StringToByteArray(CPouch5Id.Text));
                gecko.WriteShort(pouchpointer + 0x12, Convert.ToInt16(CPouch5Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x14, gecko.StringToByteArray(CPouch6Id.Text));
                gecko.WriteShort(pouchpointer + 0x16, Convert.ToInt16(CPouch6Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x18, gecko.StringToByteArray(CPouch7Id.Text));
                gecko.WriteShort(pouchpointer + 0x1A, Convert.ToInt16(CPouch7Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x1C, gecko.StringToByteArray(CPouch8Id.Text));
                gecko.WriteShort(pouchpointer + 0x1E, Convert.ToInt16(CPouch8Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x20, gecko.StringToByteArray(CPouch9Id.Text));
                gecko.WriteShort(pouchpointer + 0x22, Convert.ToInt16(CPouch9Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x24, gecko.StringToByteArray(CPouch10Id.Text));
                gecko.WriteShort(pouchpointer + 0x26, Convert.ToInt16(CPouch10Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x28, gecko.StringToByteArray(CPouch11Id.Text));
                gecko.WriteShort(pouchpointer + 0x2A, Convert.ToInt16(CPouch11Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x2C, gecko.StringToByteArray(CPouch12Id.Text));
                gecko.WriteShort(pouchpointer + 0x2E, Convert.ToInt16(CPouch12Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x30, gecko.StringToByteArray(CPouch13Id.Text));
                gecko.WriteShort(pouchpointer + 0x32, Convert.ToInt16(CPouch13Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x34, gecko.StringToByteArray(CPouch14Id.Text));
                gecko.WriteShort(pouchpointer + 0x36, Convert.ToInt16(CPouch14Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x38, gecko.StringToByteArray(CPouch15Id.Text));
                gecko.WriteShort(pouchpointer + 0x3A, Convert.ToInt16(CPouch15Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x3C, gecko.StringToByteArray(CPouch16Id.Text));
                gecko.WriteShort(pouchpointer + 0x3E, Convert.ToInt16(CPouch16Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x40, gecko.StringToByteArray(CPouch17Id.Text));
                gecko.WriteShort(pouchpointer + 0x42, Convert.ToInt16(CPouch17Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x44, gecko.StringToByteArray(CPouch18Id.Text));
                gecko.WriteShort(pouchpointer + 0x46, Convert.ToInt16(CPouch18Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x48, gecko.StringToByteArray(CPouch19Id.Text));
                gecko.WriteShort(pouchpointer + 0x4A, Convert.ToInt16(CPouch19Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x4C, gecko.StringToByteArray(CPouch20Id.Text));
                gecko.WriteShort(pouchpointer + 0x4E, Convert.ToInt16(CPouch20Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x50, gecko.StringToByteArray(CPouch21Id.Text));
                gecko.WriteShort(pouchpointer + 0x52, Convert.ToInt16(CPouch21Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x54, gecko.StringToByteArray(CPouch22Id.Text));
                gecko.WriteShort(pouchpointer + 0x56, Convert.ToInt16(CPouch22Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x58, gecko.StringToByteArray(CPouch23Id.Text));
                gecko.WriteShort(pouchpointer + 0x5A, Convert.ToInt16(CPouch23Amount.Text));

                gecko.WriteBytes(pouchpointer + 0x5C, gecko.StringToByteArray(CPouch24Id.Text));
                gecko.WriteShort(pouchpointer + 0x5E, Convert.ToInt16(CPouch24Amount.Text));
            }
            //==========================================================================================
            //Get Gunner Pouch
            //check to see if player is a gunner

            //if (gpouchpointer > 0x30000000)
            if (gpouchpointer != 0)
            {
                if (CBItemEnable.IsChecked == true)
                {
                    gecko.WriteBytes(gpouchpointer, gecko.StringToByteArray(CGPouch1Id.Text));
                    gecko.WriteShort(gpouchpointer + 0x2, Convert.ToInt16(CGPouch1Amount.Text));

                    gecko.WriteBytes(gpouchpointer + 0x4, gecko.StringToByteArray(CGPouch2Id.Text));
                    gecko.WriteShort(gpouchpointer + 0x6, Convert.ToInt16(CGPouch2Amount.Text));

                    gecko.WriteBytes(gpouchpointer + 0x8, gecko.StringToByteArray(CGPouch3Id.Text));
                    gecko.WriteShort(gpouchpointer + 0xA, Convert.ToInt16(CGPouch3Amount.Text));

                    gecko.WriteBytes(gpouchpointer + 0xC, gecko.StringToByteArray(CGPouch4Id.Text));
                    gecko.WriteShort(gpouchpointer + 0xE, Convert.ToInt16(CGPouch4Amount.Text));

                    gecko.WriteBytes(gpouchpointer + 0x10, gecko.StringToByteArray(CGPouch5Id.Text));
                    gecko.WriteShort(gpouchpointer + 0x12, Convert.ToInt16(CGPouch5Amount.Text));

                    gecko.WriteBytes(gpouchpointer + 0x14, gecko.StringToByteArray(CGPouch6Id.Text));
                    gecko.WriteShort(gpouchpointer + 0x16, Convert.ToInt16(CGPouch6Amount.Text));

                    gecko.WriteBytes(gpouchpointer + 0x18, gecko.StringToByteArray(CGPouch7Id.Text));
                    gecko.WriteShort(gpouchpointer + 0x1A, Convert.ToInt16(CGPouch7Amount.Text));

                    gecko.WriteBytes(gpouchpointer + 0x1C, gecko.StringToByteArray(CGPouch8Id.Text));
                    gecko.WriteShort(gpouchpointer + 0x1E, Convert.ToInt16(CGPouch8Amount.Text));
                }
            }

            return;

        }

        private void Read1Click(object sender, RoutedEventArgs e)
        {
            Int32 WeaponAddress = 0x2F4495E0;
            int PageNum = 0x640;
            int RowNum = 0xA0;
            int ColNum = 0x10;

            var SelPage = (Convert.ToInt32(WPage1.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(WRow1.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(WCol1.SelectedItem)) - 1;

            //Now set the write field to be the same
            WPage61.SelectedItem = WPage1.SelectedItem;
            WRow61.SelectedItem = WRow1.SelectedItem;
            WCol61.SelectedItem = WCol1.SelectedItem;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

            Address1.Text = WeaponPointer.ToString("X8");

            //set the write address to be the same
            Address61.Text = WeaponPointer.ToString("X8");

            var weapondata = gecko.ReadBytes(WeaponPointer, 0x10);

            if (weapondata.Length > 0 && weapondata != null)
            {
                var tdata1 = BitConverter.ToInt32(weapondata.Skip(0).Take(4).Reverse().ToArray(), 0);
                var tdata2 = BitConverter.ToInt32(weapondata.Skip(4).Take(4).Reverse().ToArray(), 0);
                var tdata3 = BitConverter.ToInt32(weapondata.Skip(8).Take(4).Reverse().ToArray(), 0);
                var tdata4 = BitConverter.ToInt32(weapondata.Skip(12).Take(4).Reverse().ToArray(), 0);

                Data1.Text = tdata1.ToString("X8");
                Data2.Text = tdata2.ToString("X8");
                Data3.Text = tdata3.ToString("X8");
                Data4.Text = tdata4.ToString("X8");

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = tdata1.ToString("X8");
                Data62.Text = tdata2.ToString("X8");
                Data63.Text = tdata3.ToString("X8");
                Data64.Text = tdata4.ToString("X8");
            }
            else
            {
                Data1.Text = "00000000";
                Data2.Text = "00000000"; 
                Data3.Text = "00000000"; 
                Data4.Text = "00000000";

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = "00000000";
                Data62.Text = "00000000";
                Data63.Text = "00000000";
                Data64.Text = "00000000";
            }

        }

        private void Read2Click(object sender, RoutedEventArgs e)
        {
            Int32 WeaponAddress = 0x2F4495E0;
            int PageNum = 0x640;
            int RowNum = 0xA0;
            int ColNum = 0x10;

            var SelPage = (Convert.ToInt32(WPage21.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(WRow21.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(WCol21.SelectedItem)) - 1;

            //Now set the write field to be the same
            WPage61.SelectedItem = WPage21.SelectedItem;
            WRow61.SelectedItem = WRow21.SelectedItem;
            WCol61.SelectedItem = WCol21.SelectedItem;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

            Address21.Text = WeaponPointer.ToString("X8");

            //set the write address to be the same
            Address61.Text = WeaponPointer.ToString("X8");

            var weapondata = gecko.ReadBytes(WeaponPointer, 0x10);

            if (weapondata.Length > 0 && weapondata != null)
            {
                var tdata21 = BitConverter.ToInt32(weapondata.Skip(0).Take(4).Reverse().ToArray(), 0);
                var tdata22 = BitConverter.ToInt32(weapondata.Skip(4).Take(4).Reverse().ToArray(), 0);
                var tdata23 = BitConverter.ToInt32(weapondata.Skip(8).Take(4).Reverse().ToArray(), 0);
                var tdata24 = BitConverter.ToInt32(weapondata.Skip(12).Take(4).Reverse().ToArray(), 0);

                Data21.Text = tdata21.ToString("X8");
                Data22.Text = tdata22.ToString("X8");
                Data23.Text = tdata23.ToString("X8");
                Data24.Text = tdata24.ToString("X8");

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = tdata21.ToString("X8");
                Data62.Text = tdata22.ToString("X8");
                Data63.Text = tdata23.ToString("X8");
                Data64.Text = tdata24.ToString("X8");
            }
            else
            {
                Data21.Text = "00000000";
                Data22.Text = "00000000";
                Data23.Text = "00000000";
                Data24.Text = "00000000";

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = "00000000";
                Data62.Text = "00000000";
                Data63.Text = "00000000";
                Data64.Text = "00000000";
            }

        }

        private void Read3Click(object sender, RoutedEventArgs e)
        {
            Int32 WeaponAddress = 0x2F4495E0;
            int PageNum = 0x640;
            int RowNum = 0xA0;
            int ColNum = 0x10;

            var SelPage = (Convert.ToInt32(WPage31.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(WRow31.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(WCol31.SelectedItem)) - 1;

            //Now set the write field to be the same
            WPage61.SelectedItem = WPage31.SelectedItem;
            WRow61.SelectedItem = WRow31.SelectedItem;
            WCol61.SelectedItem = WCol31.SelectedItem;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

            Address31.Text = WeaponPointer.ToString("X8");

            //set the write address to be the same
            Address61.Text = WeaponPointer.ToString("X8");

            var weapondata = gecko.ReadBytes(WeaponPointer, 0x10);

            if (weapondata.Length > 0 && weapondata != null)
            {
                var tdata31 = BitConverter.ToInt32(weapondata.Skip(0).Take(4).Reverse().ToArray(), 0);
                var tdata32 = BitConverter.ToInt32(weapondata.Skip(4).Take(4).Reverse().ToArray(), 0);
                var tdata33 = BitConverter.ToInt32(weapondata.Skip(8).Take(4).Reverse().ToArray(), 0);
                var tdata34 = BitConverter.ToInt32(weapondata.Skip(12).Take(4).Reverse().ToArray(), 0);

                Data31.Text = tdata31.ToString("X8");
                Data32.Text = tdata32.ToString("X8");
                Data33.Text = tdata33.ToString("X8");
                Data34.Text = tdata34.ToString("X8");

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = tdata31.ToString("X8");
                Data62.Text = tdata32.ToString("X8");
                Data63.Text = tdata33.ToString("X8");
                Data64.Text = tdata34.ToString("X8");
            }
            else
            {
                Data31.Text = "00000000";
                Data32.Text = "00000000";
                Data33.Text = "00000000";
                Data34.Text = "00000000";

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = "00000000";
                Data62.Text = "00000000";
                Data63.Text = "00000000";
                Data64.Text = "00000000";
            }
        }

        private void Read4Click(object sender, RoutedEventArgs e)
        {
            Int32 WeaponAddress = 0x2F4495E0;
            int PageNum = 0x640;
            int RowNum = 0xA0;
            int ColNum = 0x10;

            var SelPage = (Convert.ToInt32(WPage41.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(WRow41.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(WCol41.SelectedItem)) - 1;

            //Now set the write field to be the same
            WPage61.SelectedItem = WPage41.SelectedItem;
            WRow61.SelectedItem = WRow41.SelectedItem;
            WCol61.SelectedItem = WCol41.SelectedItem;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

            Address41.Text = WeaponPointer.ToString("X8");

            //set the write address to be the same
            Address61.Text = WeaponPointer.ToString("X8");

            var weapondata = gecko.ReadBytes(WeaponPointer, 0x10);

            if (weapondata.Length > 0 && weapondata != null)
            {
                var tdata41 = BitConverter.ToInt32(weapondata.Skip(0).Take(4).Reverse().ToArray(), 0);
                var tdata42 = BitConverter.ToInt32(weapondata.Skip(4).Take(4).Reverse().ToArray(), 0);
                var tdata43 = BitConverter.ToInt32(weapondata.Skip(8).Take(4).Reverse().ToArray(), 0);
                var tdata44 = BitConverter.ToInt32(weapondata.Skip(12).Take(4).Reverse().ToArray(), 0);

                Data41.Text = tdata41.ToString("X8");
                Data42.Text = tdata42.ToString("X8");
                Data43.Text = tdata43.ToString("X8");
                Data44.Text = tdata44.ToString("X8");

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = tdata41.ToString("X8");
                Data62.Text = tdata42.ToString("X8");
                Data63.Text = tdata43.ToString("X8");
                Data64.Text = tdata44.ToString("X8");
            }
            else
            {
                Data41.Text = "00000000";
                Data42.Text = "00000000";
                Data43.Text = "00000000";
                Data44.Text = "00000000";

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = "00000000";
                Data62.Text = "00000000";
                Data63.Text = "00000000";
                Data64.Text = "00000000";
            }
        }

        private void Read5Click(object sender, RoutedEventArgs e)
        {
            Int32 WeaponAddress = 0x2F4495E0;
            int PageNum = 0x640;
            int RowNum = 0xA0;
            int ColNum = 0x10;

            var SelPage = (Convert.ToInt32(WPage51.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(WRow51.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(WCol51.SelectedItem)) - 1;

            //Now set the write field to be the same
            WPage61.SelectedItem = WPage51.SelectedItem;
            WRow61.SelectedItem = WRow51.SelectedItem;
            WCol61.SelectedItem = WCol51.SelectedItem;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

            Address51.Text = WeaponPointer.ToString("X8");

            //set the write address to be the same
            Address61.Text = WeaponPointer.ToString("X8");

            var weapondata = gecko.ReadBytes(WeaponPointer, 0x10);

            if (weapondata.Length > 0 && weapondata != null)
            {
                var tdata51 = BitConverter.ToInt32(weapondata.Skip(0).Take(4).Reverse().ToArray(), 0);
                var tdata52 = BitConverter.ToInt32(weapondata.Skip(4).Take(4).Reverse().ToArray(), 0);
                var tdata53 = BitConverter.ToInt32(weapondata.Skip(8).Take(4).Reverse().ToArray(), 0);
                var tdata54 = BitConverter.ToInt32(weapondata.Skip(12).Take(4).Reverse().ToArray(), 0);

                Data51.Text = tdata51.ToString("X8");
                Data52.Text = tdata52.ToString("X8");
                Data53.Text = tdata53.ToString("X8");
                Data54.Text = tdata54.ToString("X8");

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = tdata51.ToString("X8");
                Data62.Text = tdata52.ToString("X8");
                Data63.Text = tdata53.ToString("X8");
                Data64.Text = tdata54.ToString("X8");
            }
            else
            {
                Data51.Text = "00000000";
                Data52.Text = "00000000";
                Data53.Text = "00000000";
                Data54.Text = "00000000";

                //populate the write field,just in case user wants
                //to modified that field instead
                Data61.Text = "00000000";
                Data62.Text = "00000000";
                Data63.Text = "00000000";
                Data64.Text = "00000000";
            }
        }

        private void WeaponWriteClick(object sender, RoutedEventArgs e)
        {
            Int32 WeaponAddress = 0x2F4495E0;
            int PageNum = 0x640;
            int RowNum = 0xA0;
            int ColNum = 0x10;

            var SelPage = (Convert.ToInt32(WPage61.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(WRow61.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(WCol61.SelectedItem)) - 1;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

            Address61.Text = WeaponPointer.ToString("X8");

            gecko.WriteBytes(WeaponPointer, gecko.StringToByteArray(Data61.Text));
            gecko.WriteBytes(WeaponPointer + 0x4, gecko.StringToByteArray(Data62.Text));
            gecko.WriteBytes(WeaponPointer + 0x8, gecko.StringToByteArray(Data63.Text));
            gecko.WriteBytes(WeaponPointer + 0xC, gecko.StringToByteArray(Data64.Text));

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Win1.Show();
        }

        private void EQType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int TmpID = EQType.SelectedIndex;
            string Tmp = EQType.SelectedItem.ToString();
            string chest = Equipment_ID[1, 1];
            string arm = Equipment_ID[2, 1];
            string waist = Equipment_ID[3, 1];
            string pants = Equipment_ID[4, 1];
            string head = Equipment_ID[5, 1];
            string charm = Equipment_ID[6, 1];


            if (Tmp == chest || Tmp == arm || Tmp == waist || Tmp == pants || Tmp == head)
            {
                //Selected some armor
                EquipmentView("armor", Tmp);
                EQSkill1.Items.Clear();
            }
            else if (Tmp == charm)
            {
                //selected talisman
                EquipmentView("talisman", Tmp);

                int TmpCnt = Convert.ToInt32(CharmSkills[0, 1]);
                EQSkill1.Items.Add("None");

                for (int i = 1; i <= TmpCnt; i++)
                {
                    EQSkill1.Items.Add(CharmSkills[i, 1]);
                }
                
            }
            else if (Tmp == "None")
            {
                //selected nothing
                EquipmentView("initialize", "none");
            }
            else
            {
                //rest is assume to be weapons
                EquipmentView("weapon", Tmp);
                EQSkill1.Items.Clear();
            }

            EQSkill1.SelectedIndex = 0;
            EQSkill2.SelectedIndex = 0;
            EQRData1.Text = "00000000";
            EQWData2.Text = "00000000";
            EQRData3.Text = "00000000";
            EQWData4.Text = "00000000";
            EQAmt1.Text = "00";
            EQAmt2.Text = "00";
            EQRare.SelectedIndex = 0;
            EQSlots.SelectedIndex = 0;
            JwlSP1.SelectedIndex = 0;
            JwlSP2.SelectedIndex = 0;
            JwlSP3.SelectedIndex = 0;

            string EQID = Equipment_ID[TmpID, 0];
            string TmpEQWrite = EQWData1.Text;
            TmpEQWrite = TmpEQWrite.Remove(0, 2).Insert(0, EQID);
            EQWData1.Text = TmpEQWrite;

            EQViewFlag = true;

        }

        private void EQReadClick(object sender, RoutedEventArgs e)
        {
            Int32 WeaponAddress = 0x2F4495E0;
            int PageNum = 0x640;
            int RowNum = 0xA0;
            int ColNum = 0x10;

            var SelPage = (Convert.ToInt32(EQRPage.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(EQRRow.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(EQRCol.SelectedItem)) - 1;

            //Now set the write field to be the same
            EQWPage.SelectedItem = EQRPage.SelectedItem;
            EQWRow.SelectedItem = EQRRow.SelectedItem;
            EQWCol.SelectedItem = EQRCol.SelectedItem;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

            EQRAddress.Text = WeaponPointer.ToString("X8");

            //set the write address to be the same
            EQWAddress.Text = WeaponPointer.ToString("X8");

            var weapondata = gecko.ReadBytes(WeaponPointer, 0x10);

            if (weapondata.Length > 0 && weapondata != null)
            {
                var tdata1 = BitConverter.ToInt32(weapondata.Skip(0).Take(4).Reverse().ToArray(), 0);
                var tdata2 = BitConverter.ToInt32(weapondata.Skip(4).Take(4).Reverse().ToArray(), 0);
                var tdata3 = BitConverter.ToInt32(weapondata.Skip(8).Take(4).Reverse().ToArray(), 0);
                var tdata4 = BitConverter.ToInt32(weapondata.Skip(12).Take(4).Reverse().ToArray(), 0);

                EQRData1.Text = tdata1.ToString("X8");
                EQRData2 .Text = tdata2.ToString("X8");
                EQRData3.Text = tdata3.ToString("X8");
                EQRData4.Text = tdata4.ToString("X8");

                //populate the write field,just in case user wants
                //to modified that field instead
                EQWData1.Text = tdata1.ToString("X8");
                EQWData2.Text = tdata2.ToString("X8");
                EQWData3.Text = tdata3.ToString("X8");
                EQWData4.Text = tdata4.ToString("X8");
            }
            else
            {
                EQRData1.Text = "00000000";
                EQRData2.Text = "00000000";
                EQRData3.Text = "00000000";
                EQRData4.Text = "00000000";

                //populate the write field,just in case user wants
                //to modified that field instead
                EQWData1.Text = "00000000";
                EQWData2.Text = "00000000";
                EQWData3.Text = "00000000";
                EQWData4.Text = "00000000";
            }

            //Get the first 2 char from data1
            string TmpData1 = EQRData1.Text;
            string EQRType = TmpData1.Substring(0,2);

            var IDIndex = LookUpArrayID(EQRType, Equipment_ID);
            EQViewFlag = false;
            EQType.SelectedIndex = IDIndex;

            Stopwatch s = new Stopwatch();
            s.Start();
            while (s.Elapsed < TimeSpan.FromSeconds(1))
            {
                if (s.Elapsed > TimeSpan.FromSeconds(1))
                { s.Stop(); }
                //something when wrong
            }

            s.Stop();
        }

        private void ItemRead1Click(object sender, RoutedEventArgs e)
        {
            Int32 ItemBoxAddress = 0x2F448640;
            int PageNum = 0x190;
            int RowNum = 0x28;
            int ColNum = 0x04;

            var SelPage = (Convert.ToInt32(ItemRPage1.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(ItemRRow1.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(ItemRCol1.SelectedItem)) - 1;

            //Now set the write field to be the same
            ItemWPage.SelectedItem = ItemRPage1.SelectedItem;
            ItemWRow.SelectedItem = ItemRRow1.SelectedItem;
            ItemWCol.SelectedItem = ItemRCol1.SelectedItem;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var ItemBoxPointer = Convert.ToUInt32(ItemBoxAddress + OffSet);

            ItemAddr1.Text = ItemBoxPointer.ToString("X8");

            //set the write address to be the same
            ItemAddr3.Text = ItemBoxPointer.ToString("X8");

            var Itemdata = gecko.ReadBytes(ItemBoxPointer, 0x04);

            if (Itemdata.Length > 0 && Itemdata != null)
            {
                var tdata1 = BitConverter.ToString(Itemdata.Skip(0).Take(2).ToArray()).Replace("-", "");
                var tdata2 = BitConverter.ToInt16(Itemdata.Skip(2).Take(2).Reverse().ToArray(), 0).ToString();

                            
                ItemID1.Text = tdata1;
                ItemAmt1.Text = tdata2;
                
                //populate the write field,just in case user wants
                //to modified that field instead
                ItemID3.Text = tdata1;
                ItemAmt3.Text = tdata2;

                //now populate the name, search for the ID
                int SelItemID = LookUpArrayID(ItemID1.Text,ItemNames);

                ItemName1.Text = ItemNames[SelItemID,1];
                ItemNameList.SelectedIndex = SelItemID;

            }
            else
            {
                ItemID1.Text = "0000";
                ItemName1.Text = "None";
                ItemAmt1.Text = "00";

                //populate the write field,just in case user wants
                //to modified that field instead
                ItemID3.Text = "0000";
                ItemNameList.SelectedIndex = 0;
                ItemAmt3.Text = "00";

            }
        }

        private void ItemRead2Click(object sender, RoutedEventArgs e)
        {
            Int32 ItemBoxAddress = 0x2F448640;
            int PageNum = 0x190;
            int RowNum = 0x28;
            int ColNum = 0x04;

            var SelPage = (Convert.ToInt32(ItemRPage2.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(ItemRRow2.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(ItemRCol2.SelectedItem)) - 1;

            //Now set the write field to be the same
            ItemWPage.SelectedItem = ItemRPage2.SelectedItem;
            ItemWRow.SelectedItem = ItemRRow2.SelectedItem;
            ItemWCol.SelectedItem = ItemRCol2.SelectedItem;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var ItemBoxPointer = Convert.ToUInt32(ItemBoxAddress + OffSet);

            ItemAddr2.Text = ItemBoxPointer.ToString("X8");

            //set the write address to be the same
            ItemAddr3.Text = ItemBoxPointer.ToString("X8");

            var Itemdata = gecko.ReadBytes(ItemBoxPointer, 0x04);

            if (Itemdata.Length > 0 && Itemdata != null)
            {
                var tdata1 = BitConverter.ToString(Itemdata.Skip(0).Take(2).ToArray()).Replace("-", "");
                var tdata2 = BitConverter.ToInt16(Itemdata.Skip(2).Take(2).Reverse().ToArray(), 0).ToString();


                ItemID2.Text = tdata1;
                ItemAmt2.Text = tdata2;

                //populate the write field,just in case user wants
                //to modified that field instead
                ItemID3.Text = tdata1;
                ItemAmt3.Text = tdata2;

                //now populate the name, search for the ID
                int SelItemID = LookUpArrayID(ItemID2.Text, ItemNames);

                ItemName2.Text = ItemNames[SelItemID, 1];
                ItemNameList.SelectedIndex = SelItemID;

            }
            else
            {
                ItemID2.Text = "0000";
                ItemName2.Text = "None";
                ItemAmt2.Text = "00";

                //populate the write field,just in case user wants
                //to modified that field instead
                ItemID3.Text = "0000";
                ItemNameList.SelectedIndex = 0;
                ItemAmt3.Text = "00";

            }
        }

        private void ItemWriteClick(object sender, RoutedEventArgs e)
        {
            Int32 ItemBoxAddress = 0x2F448640;
            int PageNum = 0x190;
            int RowNum = 0x28;
            int ColNum = 0x04;

            var SelPage = (Convert.ToInt32(ItemWPage.SelectedItem)) - 1;
            var SelRow = (Convert.ToInt32(ItemWRow.SelectedItem)) - 1;
            var SelCol = (Convert.ToInt32(ItemWCol.SelectedItem)) - 1;

            var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

            var ItemBoxPointer = Convert.ToUInt32(ItemBoxAddress + OffSet);

            ItemAddr3.Text = ItemBoxPointer.ToString("X8");

            gecko.WriteBytes(ItemBoxPointer, gecko.StringToByteArray(ItemID3.Text));
            gecko.WriteShort(ItemBoxPointer + 0x2, Convert.ToInt16(ItemAmt3.Text));

        }

        private void ItemNameList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = ItemNameList.SelectedIndex;
            string ItemID = ItemNames[Tmp,0];
            ItemID3.Text = ItemID;
        }

        private void ItemID3_LostFocus(object sender, TextChangedEventArgs e)
        {
            if (ItemID3.Text.Length >= 4)
            {   //now populate the name, search for the ID
                int SelItemID = LookUpArrayID(ItemID3.Text, ItemNames);
                ItemNameList.SelectedIndex = SelItemID;
            }
        }

        private void Pouch_Click(object sender, RoutedEventArgs e)
        {
            string TmpPouchSpaceNum = PouchSpaceNum.Text;
            int TmpPouchNameIndex = PItemNameList.SelectedIndex;

            string TmpItemID = UItemNames[TmpPouchNameIndex,0];
            string TmpItemName = UItemNames[TmpPouchNameIndex, 1];

            if (TmpItemName == UItemNames[0, 1])
            { TmpItemName = "None"; }

            switch (TmpPouchSpaceNum) {
                case "1": CPouch1Id.Text = TmpItemID; CPouch1Name.Text = TmpItemName; CPouch1Amount.Text = PItemAmount.Text; break;
                case "2": CPouch2Id.Text = TmpItemID; CPouch2Name.Text = TmpItemName; CPouch2Amount.Text = PItemAmount.Text; break;
                case "3": CPouch3Id.Text = TmpItemID; CPouch3Name.Text = TmpItemName; CPouch3Amount.Text = PItemAmount.Text; break;
                case "4": CPouch4Id.Text = TmpItemID; CPouch4Name.Text = TmpItemName; CPouch4Amount.Text = PItemAmount.Text; break;
                case "5": CPouch5Id.Text = TmpItemID; CPouch5Name.Text = TmpItemName; CPouch5Amount.Text = PItemAmount.Text; break;
                case "6": CPouch6Id.Text = TmpItemID; CPouch6Name.Text = TmpItemName; CPouch6Amount.Text = PItemAmount.Text; break;
                case "7": CPouch7Id.Text = TmpItemID; CPouch7Name.Text = TmpItemName; CPouch7Amount.Text = PItemAmount.Text; break;
                case "8": CPouch8Id.Text = TmpItemID; CPouch8Name.Text = TmpItemName; CPouch8Amount.Text = PItemAmount.Text; break;
                case "9": CPouch9Id.Text = TmpItemID; CPouch9Name.Text = TmpItemName; CPouch9Amount.Text = PItemAmount.Text; break;
                case "10": CPouch10Id.Text = TmpItemID; CPouch10Name.Text = TmpItemName; CPouch10Amount.Text = PItemAmount.Text; break;
                case "11": CPouch11Id.Text = TmpItemID; CPouch11Name.Text = TmpItemName; CPouch11Amount.Text = PItemAmount.Text; break;
                case "12": CPouch12Id.Text = TmpItemID; CPouch12Name.Text = TmpItemName; CPouch12Amount.Text = PItemAmount.Text; break;
                case "13": CPouch13Id.Text = TmpItemID; CPouch13Name.Text = TmpItemName; CPouch13Amount.Text = PItemAmount.Text; break;
                case "14": CPouch14Id.Text = TmpItemID; CPouch14Name.Text = TmpItemName; CPouch14Amount.Text = PItemAmount.Text; break;
                case "15": CPouch15Id.Text = TmpItemID; CPouch15Name.Text = TmpItemName; CPouch15Amount.Text = PItemAmount.Text; break;
                case "16": CPouch16Id.Text = TmpItemID; CPouch16Name.Text = TmpItemName; CPouch16Amount.Text = PItemAmount.Text; break;
                case "17": CPouch17Id.Text = TmpItemID; CPouch17Name.Text = TmpItemName; CPouch17Amount.Text = PItemAmount.Text; break;
                case "18": CPouch18Id.Text = TmpItemID; CPouch18Name.Text = TmpItemName; CPouch18Amount.Text = PItemAmount.Text; break;
                case "19": CPouch19Id.Text = TmpItemID; CPouch19Name.Text = TmpItemName; CPouch19Amount.Text = PItemAmount.Text; break;
                case "20": CPouch20Id.Text = TmpItemID; CPouch20Name.Text = TmpItemName; CPouch20Amount.Text = PItemAmount.Text; break;
                case "21": CPouch21Id.Text = TmpItemID; CPouch21Name.Text = TmpItemName; CPouch21Amount.Text = PItemAmount.Text; break;
                case "22": CPouch22Id.Text = TmpItemID; CPouch22Name.Text = TmpItemName; CPouch22Amount.Text = PItemAmount.Text; break;
                case "23": CPouch23Id.Text = TmpItemID; CPouch23Name.Text = TmpItemName; CPouch23Amount.Text = PItemAmount.Text; break;
                case "24": CPouch24Id.Text = TmpItemID; CPouch24Name.Text = TmpItemName; CPouch24Amount.Text = PItemAmount.Text; break;
                case "G1": CGPouch1Id.Text = TmpItemID; CGPouch1Name.Text = TmpItemName; CGPouch1Amount.Text = PItemAmount.Text; break;
                case "G2": CGPouch2Id.Text = TmpItemID; CGPouch2Name.Text = TmpItemName; CGPouch2Amount.Text = PItemAmount.Text; break;
                case "G3": CGPouch3Id.Text = TmpItemID; CGPouch3Name.Text = TmpItemName; CGPouch3Amount.Text = PItemAmount.Text; break;
                case "G4": CGPouch4Id.Text = TmpItemID; CGPouch4Name.Text = TmpItemName; CGPouch4Amount.Text = PItemAmount.Text; break;
                case "G5": CGPouch5Id.Text = TmpItemID; CGPouch5Name.Text = TmpItemName; CGPouch5Amount.Text = PItemAmount.Text; break;
                case "G6": CGPouch6Id.Text = TmpItemID; CGPouch6Name.Text = TmpItemName; CGPouch6Amount.Text = PItemAmount.Text; break;
                case "G7": CGPouch7Id.Text = TmpItemID; CGPouch7Name.Text = TmpItemName; CGPouch7Amount.Text = PItemAmount.Text; break;
                case "G8": CGPouch8Id.Text = TmpItemID; CGPouch8Name.Text = TmpItemName; CGPouch8Amount.Text = PItemAmount.Text; break;
                default: break;
            }

        }

        private void PClear_Click(object sender, RoutedEventArgs e)
        {
            string TmpPouchSpaceNum = PouchSpaceNum.Text;

            switch (TmpPouchSpaceNum)
            {
                case "1": CPouch1Id.Text = "0000"; CPouch1Name.Text = ""; CPouch1Amount.Text = "0"; break;
                case "2": CPouch2Id.Text = "0000"; CPouch2Name.Text = ""; CPouch2Amount.Text = "0"; break;
                case "3": CPouch3Id.Text = "0000"; CPouch3Name.Text = ""; CPouch3Amount.Text = "0"; break;
                case "4": CPouch4Id.Text = "0000"; CPouch4Name.Text = ""; CPouch4Amount.Text = "0"; break;
                case "5": CPouch5Id.Text = "0000"; CPouch5Name.Text = ""; CPouch5Amount.Text = "0"; break;
                case "6": CPouch6Id.Text = "0000"; CPouch6Name.Text = ""; CPouch6Amount.Text = "0"; break;
                case "7": CPouch7Id.Text = "0000"; CPouch7Name.Text = ""; CPouch7Amount.Text = "0"; break;
                case "8": CPouch8Id.Text = "0000"; CPouch8Name.Text = ""; CPouch8Amount.Text = "0"; break;
                case "9": CPouch9Id.Text = "0000"; CPouch9Name.Text = ""; CPouch9Amount.Text = "0"; break;
                case "10": CPouch10Id.Text = "0000"; CPouch10Name.Text = ""; CPouch10Amount.Text = "0"; break;
                case "11": CPouch11Id.Text = "0000"; CPouch11Name.Text = ""; CPouch11Amount.Text = "0"; break;
                case "12": CPouch12Id.Text = "0000"; CPouch12Name.Text = ""; CPouch12Amount.Text = "0"; break;
                case "13": CPouch13Id.Text = "0000"; CPouch13Name.Text = ""; CPouch13Amount.Text = "0"; break;
                case "14": CPouch14Id.Text = "0000"; CPouch14Name.Text = ""; CPouch14Amount.Text = "0"; break;
                case "15": CPouch15Id.Text = "0000"; CPouch15Name.Text = ""; CPouch15Amount.Text = "0"; break;
                case "16": CPouch16Id.Text = "0000"; CPouch16Name.Text = ""; CPouch16Amount.Text = "0"; break;
                case "17": CPouch17Id.Text = "0000"; CPouch17Name.Text = ""; CPouch17Amount.Text = "0"; break;
                case "18": CPouch18Id.Text = "0000"; CPouch18Name.Text = ""; CPouch18Amount.Text = "0"; break;
                case "19": CPouch19Id.Text = "0000"; CPouch19Name.Text = ""; CPouch19Amount.Text = "0"; break;
                case "20": CPouch20Id.Text = "0000"; CPouch20Name.Text = ""; CPouch20Amount.Text = "0"; break;
                case "21": CPouch21Id.Text = "0000"; CPouch21Name.Text = ""; CPouch21Amount.Text = "0"; break;
                case "22": CPouch22Id.Text = "0000"; CPouch22Name.Text = ""; CPouch22Amount.Text = "0"; break;
                case "23": CPouch23Id.Text = "0000"; CPouch23Name.Text = ""; CPouch23Amount.Text = "0"; break;
                case "24": CPouch24Id.Text = "0000"; CPouch24Name.Text = ""; CPouch24Amount.Text = "0"; break;
                case "G1": CGPouch1Id.Text = "0000"; CGPouch1Name.Text = ""; CGPouch1Amount.Text = "0"; break;
                case "G2": CGPouch2Id.Text = "0000"; CGPouch2Name.Text = ""; CGPouch2Amount.Text = "0"; break;
                case "G3": CGPouch3Id.Text = "0000"; CGPouch3Name.Text = ""; CGPouch3Amount.Text = "0"; break;
                case "G4": CGPouch4Id.Text = "0000"; CGPouch4Name.Text = ""; CGPouch4Amount.Text = "0"; break;
                case "G5": CGPouch5Id.Text = "0000"; CGPouch5Name.Text = ""; CGPouch5Amount.Text = "0"; break;
                case "G6": CGPouch6Id.Text = "0000"; CGPouch6Name.Text = ""; CGPouch6Amount.Text = "0"; break;
                case "G7": CGPouch7Id.Text = "0000"; CGPouch7Name.Text = ""; CGPouch7Amount.Text = "0"; break;
                case "G8": CGPouch8Id.Text = "0000"; CGPouch8Name.Text = ""; CGPouch8Amount.Text = "0"; break;
                default: break;
            }
        }

        private void ReadSkillsClick(object sender, RoutedEventArgs e)
        {
            int TempID;

            //=================================================
            var playerpointer = gecko.GetUInt(0x2F41FAFC);

            if (playerpointer != 0x0 && playerpointer < 0x30000000)
            {
                //Player is probably not on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.Yes)
                {
                    MessageBox.Show("Error: Player data not found! You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                    return;

                }
                                
                //Read Food Skill
                var foodaddress = Convert.ToUInt32(0x2F42A64E);
                var fooddata = gecko.ReadBytes(foodaddress, 0x06);

                if (fooddata.Length > 0 && fooddata != null)
                {
                    FoodSkill1.Text = BitConverter.ToString(fooddata.Skip(0).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(FoodSkill1.Text, FoodSkills);
                    FoodSkillName1.SelectedIndex = TempID;

                    FoodSkill2.Text = BitConverter.ToString(fooddata.Skip(2).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(FoodSkill2.Text, FoodSkills);
                    FoodSkillName2.SelectedIndex = TempID;

                    FoodSkill3.Text = BitConverter.ToString(fooddata.Skip(4).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(FoodSkill3.Text, FoodSkills);
                    FoodSkillName3.SelectedIndex = TempID;
                }
                else
                {
                    FoodSkill1.Text = "0000";
                    FoodSkillName1.SelectedIndex = 0;
                    FoodSkill2.Text = "0000";
                    FoodSkillName2.SelectedIndex = 0;
                    FoodSkill3.Text = "0000";
                    FoodSkillName3.SelectedIndex = 0;
                }
            }
            else if (playerpointer > 0x30000000)
            {
                //Player is on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.No)
                {
                    MessageBox.Show("Error has occur! Game thinks you're on a quest. You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                    return;

                }

                //check to see if Write button has been enable
                if (WriteSkills.IsEnabled == false)
                { WriteSkills.IsEnabled = true; }

                if (Write.IsEnabled == true && WriteSkills.IsEnabled == true)
                { Replicator.IsEnabled = true; }

                //Read Food Skill
                var foodaddress = playerpointer + 0x966;
                var fooddata = gecko.ReadBytes(foodaddress, 0x06);

                if (fooddata.Length > 0 && fooddata != null)
                {
                    FoodSkill1.Text = BitConverter.ToString(fooddata.Skip(0).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(FoodSkill1.Text, FoodSkills);
                    FoodSkillName1.SelectedIndex = TempID;

                    FoodSkill2.Text = BitConverter.ToString(fooddata.Skip(2).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(FoodSkill2.Text, FoodSkills);
                    FoodSkillName2.SelectedIndex = TempID;

                    FoodSkill3.Text = BitConverter.ToString(fooddata.Skip(4).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(FoodSkill3.Text, FoodSkills);
                    FoodSkillName3.SelectedIndex = TempID;
                }
                else
                {
                    FoodSkill1.Text = "0000";
                    FoodSkillName1.SelectedIndex = 0;
                    FoodSkill2.Text = "0000";
                    FoodSkillName2.SelectedIndex = 0;
                    FoodSkill3.Text = "0000";
                    FoodSkillName3.SelectedIndex = 0;
                }

                //Read Active Skill
                var ActiveSkillAddress = playerpointer + 0x934;
                var ActiveSkillData = gecko.ReadBytes(ActiveSkillAddress, 0x14);

                if (ActiveSkillData.Length > 0 && ActiveSkillData != null)
                {
                    ActiveSkillID1.Text = BitConverter.ToString(ActiveSkillData.Skip(0).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(ActiveSkillID1.Text, PlayerSkills);
                    ActiveSkill1.SelectedIndex = TempID;

                    ActiveSkillID2.Text = BitConverter.ToString(ActiveSkillData.Skip(2).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(ActiveSkillID2.Text, PlayerSkills);
                    ActiveSkill2.SelectedIndex = TempID;

                    ActiveSkillID3.Text = BitConverter.ToString(ActiveSkillData.Skip(4).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(ActiveSkillID3.Text, PlayerSkills);
                    ActiveSkill3.SelectedIndex = TempID;

                    ActiveSkillID4.Text = BitConverter.ToString(ActiveSkillData.Skip(6).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(ActiveSkillID4.Text, PlayerSkills);
                    ActiveSkill4.SelectedIndex = TempID;

                    ActiveSkillID5.Text = BitConverter.ToString(ActiveSkillData.Skip(8).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(ActiveSkillID5.Text, PlayerSkills);
                    ActiveSkill5.SelectedIndex = TempID;

                    ActiveSkillID6.Text = BitConverter.ToString(ActiveSkillData.Skip(10).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(ActiveSkillID6.Text, PlayerSkills);
                    ActiveSkill6.SelectedIndex = TempID;

                    ActiveSkillID7.Text = BitConverter.ToString(ActiveSkillData.Skip(12).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(ActiveSkillID7.Text, PlayerSkills);
                    ActiveSkill7.SelectedIndex = TempID;

                    ActiveSkillID8.Text = BitConverter.ToString(ActiveSkillData.Skip(14).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(ActiveSkillID8.Text, PlayerSkills);
                    ActiveSkill8.SelectedIndex = TempID;

                    ActiveSkillID9.Text = BitConverter.ToString(ActiveSkillData.Skip(16).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(ActiveSkillID9.Text, PlayerSkills);
                    ActiveSkill9.SelectedIndex = TempID;

                    ActiveSkillID10.Text = BitConverter.ToString(ActiveSkillData.Skip(18).Take(2).ToArray()).Replace("-", "");
                    TempID = LookUpArrayID(ActiveSkillID10.Text, PlayerSkills);
                    ActiveSkill10.SelectedIndex = TempID;
                                      
                }
                else
                {
                    ActiveSkillID1.Text = "0000";
                    ActiveSkill1.SelectedIndex = 0;

                    ActiveSkillID2.Text = "0000";
                    ActiveSkill2.SelectedIndex = 0;

                    ActiveSkillID3.Text = "0000";
                    ActiveSkill3.SelectedIndex = 0;

                    ActiveSkillID4.Text = "0000";
                    ActiveSkill4.SelectedIndex = 0;

                    ActiveSkillID5.Text = "0000";
                    ActiveSkill5.SelectedIndex = 0;

                    ActiveSkillID6.Text = "0000";
                    ActiveSkill6.SelectedIndex = 0;

                    ActiveSkillID7.Text = "0000";
                    ActiveSkill7.SelectedIndex = 0;

                    ActiveSkillID8.Text = "0000";
                    ActiveSkill8.SelectedIndex = 0;

                    ActiveSkillID9.Text = "0000";
                    ActiveSkill9.SelectedIndex = 0;

                    ActiveSkillID10.Text = "0000";
                    ActiveSkill10.SelectedIndex = 0;

                }

            }
            else
            {
                MessageBox.Show("Player data invalid. You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                return;
            }
        }

        private void WriteSkillsClick(object sender, RoutedEventArgs e)
        {
            var playerpointer = gecko.GetUInt(0x2F41FAFC);

            if (playerpointer != 0x0 && playerpointer < 0x30000000)
            {
                //Player is probably not on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.Yes)
                {
                    MessageBox.Show("Error: Player data not found! You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                    return;

                }
                                
                //Write food skill
                var foodaddress = Convert.ToUInt32(0x2F42A64E);

                gecko.WriteBytes(foodaddress, gecko.StringToByteArray(FoodSkill1.Text));
                gecko.WriteBytes(foodaddress + 0x2, gecko.StringToByteArray(FoodSkill2.Text));
                gecko.WriteBytes(foodaddress + 0x4, gecko.StringToByteArray(FoodSkill3.Text));

            }
            else if (playerpointer > 0x30000000)
            {
                //Player is on a quest
                MessageBoxResult dialog = MessageBox.Show("Are you on a quest or outside the village?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (dialog == MessageBoxResult.No)
                {
                    MessageBox.Show("Error has occur! Game thinks you're on a quest. You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                    return;

                }

                //========================================
                if (CBFoodSkill.IsChecked == true)
                {
                    //Write food skill
                    var foodaddress = playerpointer + 0x966;

                    gecko.WriteBytes(foodaddress, gecko.StringToByteArray(FoodSkill1.Text));
                    gecko.WriteBytes(foodaddress + 0x2, gecko.StringToByteArray(FoodSkill2.Text));
                    gecko.WriteBytes(foodaddress + 0x4, gecko.StringToByteArray(FoodSkill3.Text));
                }

                //========================================
                if (CBActiveSkill.IsChecked == true)
                {
                    //Write Active skill
                    var ActiveSkillAddress = playerpointer + 0x934;

                    gecko.WriteBytes(ActiveSkillAddress, gecko.StringToByteArray(ActiveSkillID1.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0x2, gecko.StringToByteArray(ActiveSkillID2.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0x4, gecko.StringToByteArray(ActiveSkillID3.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0x6, gecko.StringToByteArray(ActiveSkillID4.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0x8, gecko.StringToByteArray(ActiveSkillID5.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0xA, gecko.StringToByteArray(ActiveSkillID6.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0xC, gecko.StringToByteArray(ActiveSkillID7.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0xE, gecko.StringToByteArray(ActiveSkillID8.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0x10, gecko.StringToByteArray(ActiveSkillID9.Text));
                    gecko.WriteBytes(ActiveSkillAddress + 0x12, gecko.StringToByteArray(ActiveSkillID10.Text));
                }
            }
            else
            {
                MessageBox.Show("Player data invalid. You need to press \"-\" button on the gamepad to show player menu. Then try again.", playerpointer.ToString("X4"));
                return;
            }
        }

        private void ActiveSkill1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = ActiveSkill1.SelectedIndex;
            string PlayerSkillsID = PlayerSkills[Tmp, 0];
            ActiveSkillID1.Text = PlayerSkillsID;
        }

        private void ActiveSkill2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = ActiveSkill2.SelectedIndex;
            string PlayerSkillsID = PlayerSkills[Tmp, 0];
            ActiveSkillID2.Text = PlayerSkillsID;
        }

        private void ActiveSkill3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = ActiveSkill3.SelectedIndex;
            string PlayerSkillsID = PlayerSkills[Tmp, 0];
            ActiveSkillID3.Text = PlayerSkillsID;
        }

        private void ActiveSkill4_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = ActiveSkill4.SelectedIndex;
            string PlayerSkillsID = PlayerSkills[Tmp, 0];
            ActiveSkillID4.Text = PlayerSkillsID;
        }

        private void ActiveSkill5_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = ActiveSkill5.SelectedIndex;
            string PlayerSkillsID = PlayerSkills[Tmp, 0];
            ActiveSkillID5.Text = PlayerSkillsID;
        }

        private void ActiveSkill6_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = ActiveSkill6.SelectedIndex;
            string PlayerSkillsID = PlayerSkills[Tmp, 0];
            ActiveSkillID6.Text = PlayerSkillsID;
        }

        private void ActiveSkill7_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = ActiveSkill7.SelectedIndex;
            string PlayerSkillsID = PlayerSkills[Tmp, 0];
            ActiveSkillID7.Text = PlayerSkillsID;
        }

        private void ActiveSkill8_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = ActiveSkill8.SelectedIndex;
            string PlayerSkillsID = PlayerSkills[Tmp, 0];
            ActiveSkillID8.Text = PlayerSkillsID;
        }

        private void ActiveSkill9_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = ActiveSkill9.SelectedIndex;
            string PlayerSkillsID = PlayerSkills[Tmp, 0];
            ActiveSkillID9.Text = PlayerSkillsID;
        }

        private void ActiveSkill10_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = ActiveSkill10.SelectedIndex;
            string PlayerSkillsID = PlayerSkills[Tmp, 0];
            ActiveSkillID10.Text = PlayerSkillsID;
        }

        private void FoodSkill1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = FoodSkillName1.SelectedIndex;
            string FoodSkillsID = FoodSkills[Tmp, 0];
            FoodSkill1.Text = FoodSkillsID;
        }

        private void FoodSkill2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = FoodSkillName2.SelectedIndex;
            string FoodSkillsID = FoodSkills[Tmp, 0];
            FoodSkill2.Text = FoodSkillsID;
        }

        private void FoodSkill3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = FoodSkillName3.SelectedIndex;
            string FoodSkillsID = FoodSkills[Tmp, 0];
            FoodSkill3.Text = FoodSkillsID;
        }

        private void WQuestClick(object sender, RoutedEventArgs e)
        {
            if (QuestID.Text != "0000")
            {
                var QuestPointer = Convert.ToUInt32(0x2F42737C);
                var QuestPicPointer = Convert.ToUInt32(0x2F4275FC);

                gecko.WriteBytes(QuestPointer, gecko.StringToByteArray(QuestID.Text));

                gecko.WriteBytes(QuestPicPointer, gecko.StringToByteArray(QuestID.Text));

                //Need to write 0100 to address to indicate a PIC
                gecko.WriteBytes(QuestPicPointer + 0x2, gecko.StringToByteArray("0100"));
            }
        }

        private void QuestData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (QuestData.SelectedIndex > 0)
            {
                DataRowView drv = (DataRowView)QuestData.SelectedItem;
                String result = (drv["ID"]).ToString();
                QuestID.Text = result;
            }
            else
            { QuestID.Text = "0000";}
        }

        private void JwlSP1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = JwlSP1.SelectedIndex;
            string CharmID = Jewels[Tmp, 0];
            string TmpEQWrite = EQWData3.Text;
            TmpEQWrite = TmpEQWrite.Remove(0,4).Insert(0,CharmID);
            EQWData3.Text = TmpEQWrite;
        }

        private void JwlSP2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = JwlSP2.SelectedIndex;
            string CharmID = Jewels[Tmp, 0];
            string TmpEQWrite = EQWData3.Text;
            TmpEQWrite = TmpEQWrite.Remove(4, 4).Insert(4, CharmID);
            EQWData3.Text = TmpEQWrite;
        }

        private void JwlSP3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = JwlSP3.SelectedIndex;
            string CharmID = Jewels[Tmp, 0];
            string TmpEQWrite = EQWData4.Text;
            TmpEQWrite = TmpEQWrite.Remove(0, 4).Insert(0, CharmID);
            EQWData4.Text = TmpEQWrite;
        }

        private void EQSkill1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = EQSkill1.SelectedIndex;
            if (Tmp >= 0 )
            {
                string CSkillsID = CharmSkills[Tmp, 0];
                string TmpEQWrite = EQWData2.Text;
                TmpEQWrite = TmpEQWrite.Remove(0, 2).Insert(0, CSkillsID);
                EQWData2.Text = TmpEQWrite;
            }
        }

        private void EQSkill2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = EQSkill2.SelectedIndex;
            string CSkillsID = CharmSkills[Tmp, 0];
            string TmpEQWrite = EQWData2.Text;
            TmpEQWrite = TmpEQWrite.Remove(4, 2).Insert(4, CSkillsID);
            EQWData2.Text = TmpEQWrite;
        }

        private void EQRare_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = EQRare.SelectedIndex;
            string RareID = Tmp.ToString("X2");
            string TmpEQWrite = EQWData1.Text;
            TmpEQWrite = TmpEQWrite.Remove(6, 2).Insert(6, RareID);
            EQWData1.Text = TmpEQWrite;

            if (Tmp == 10 && EQSlots.Text == "3")
            {
                LblJwlSp1.Visibility = Visibility.Visible;
                //LblJwlSp2.Visibility = Visibility.Visible;
                //LblJwlSp3.Visibility = Visibility.Visible;

                JwlSP1.Visibility = Visibility.Visible;
                //JwlSP2.Visibility = Visibility.Visible;
                //JwlSP3.Visibility = Visibility.Visible;
            }
            else
            {
                LblJwlSp1.Visibility = Visibility.Hidden;
                //LblJwlSp2.Visibility = Visibility.Visible;
                //LblJwlSp3.Visibility = Visibility.Visible;

                JwlSP1.Visibility = Visibility.Hidden;
                //JwlSP2.Visibility = Visibility.Visible;
                //JwlSP3.Visibility = Visibility.Visible;

                JwlSP1.SelectedIndex = 0;
                EQRData3.Text = "00000000";
                EQRData4.Text = "00000000";
            }
        }

        private void EQSlots_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Tmp = EQSlots.SelectedIndex;
            string SlotID = Tmp.ToString("X2");
            string TmpEQWrite = EQWData1.Text;
            TmpEQWrite = TmpEQWrite.Remove(2, 2).Insert(2, SlotID);
            EQWData1.Text = TmpEQWrite;

            if (Tmp == 3 && EQRare.Text == "Creator")
            {
                LblJwlSp1.Visibility = Visibility.Visible;
                //LblJwlSp2.Visibility = Visibility.Visible;
                //LblJwlSp3.Visibility = Visibility.Visible;

                JwlSP1.Visibility = Visibility.Visible;
                //JwlSP2.Visibility = Visibility.Visible;
                //JwlSP3.Visibility = Visibility.Visible;
            }
            else
            {
                LblJwlSp1.Visibility = Visibility.Hidden;
                //LblJwlSp2.Visibility = Visibility.Visible;
                //LblJwlSp3.Visibility = Visibility.Visible;

                JwlSP1.Visibility = Visibility.Hidden;
                //JwlSP2.Visibility = Visibility.Visible;
                //JwlSP3.Visibility = Visibility.Visible;

                JwlSP1.SelectedIndex = 0;
                EQRData3.Text = "00000000";
                EQRData4.Text = "00000000";
            }
        }
                
        private void EQWriteClick(object sender, RoutedEventArgs e)
        {
            if (EQType.Text == "Talisman")
            {
                int TmpVal = Convert.ToInt16(EQAmt1.Text);
                if (TmpVal > 127)
                { EQAmt1.Text = "127"; }

                sbyte NTmp = 0;
                sbyte Tmp = Convert.ToSByte(EQAmt1.Text);

                NTmp = Tmp;

                if (Tmp > 127)
                { NTmp = 127; }

                if (Tmp <= -127)
                { NTmp = -127; }

                string SkillAmt = NTmp.ToString("X2");
                string TmpEQWrite = EQWData2.Text;
                TmpEQWrite = TmpEQWrite.Remove(2, 2).Insert(2, SkillAmt);
                EQWData2.Text = TmpEQWrite;
                //==========================================================

                TmpVal = Convert.ToInt16(EQAmt2.Text);
                if (TmpVal > 127)
                { EQAmt2.Text = "127"; }

                NTmp = 0;
                Tmp = Convert.ToSByte(EQAmt2.Text);

                NTmp = Tmp;

                if (Tmp > 127)
                { NTmp = 127; }

                if (Tmp <= -127)
                { NTmp = -127; }

                SkillAmt = NTmp.ToString("X2");
                TmpEQWrite = EQWData2.Text;
                TmpEQWrite = TmpEQWrite.Remove(6, 2).Insert(6, SkillAmt);
                EQWData2.Text = TmpEQWrite;
                //=========================================================
                //Now write the data to the Wii U.
                //When all Armor and Weapons work, this part may need to be 
                //move outside of this loop.  For now only talisman works.

                Int32 WeaponAddress = 0x2F4495E0;
                int PageNum = 0x640;
                int RowNum = 0xA0;
                int ColNum = 0x10;

                var SelPage = (Convert.ToInt32(EQWPage.SelectedItem)) - 1;
                var SelRow = (Convert.ToInt32(EQWRow.SelectedItem)) - 1;
                var SelCol = (Convert.ToInt32(EQWCol.SelectedItem)) - 1;

                var OffSet = ((SelPage * PageNum) + (SelRow * RowNum) + (SelCol * ColNum));

                var WeaponPointer = Convert.ToUInt32(WeaponAddress + OffSet);

                EQWAddress.Text = WeaponPointer.ToString("X8");

                gecko.WriteBytes(WeaponPointer, gecko.StringToByteArray(EQWData1.Text));
                gecko.WriteBytes(WeaponPointer + 0x4, gecko.StringToByteArray(EQWData2.Text));
                gecko.WriteBytes(WeaponPointer + 0x8, gecko.StringToByteArray(EQWData3.Text));
                gecko.WriteBytes(WeaponPointer + 0xC, gecko.StringToByteArray(EQWData4.Text));
            }
        }
    }
}
